#ifndef __TEXTINT__H
#define __TEXTINT__H

extern void textint(void);
extern void AddFunc(void (*f)(void), unsigned char *Name, unsigned char Type, char Immediate);
extern void AddNewFunc(unsigned short CFA, unsigned char *Name, unsigned char Type, char Immediate);


extern void Lfile(unsigned char * Name);
extern unsigned char * NextWord(void);
extern unsigned char * NextWordD(unsigned char Delimiter);
extern unsigned long TestDigit(char * Str, unsigned long *iTmp);


extern int Interpret(char * Str);
extern void Upper(char * Str);

extern unsigned int Find(unsigned char *Name);



extern unsigned char REM;
extern  TAB_LOWLEVEL Exec;


typedef struct{
                unsigned short N;
                unsigned int iVal[80];
}I_DIGIT;

extern void InterpretDigit(char * Str,I_DIGIT * idig);


#endif // __TEXTINT__H
