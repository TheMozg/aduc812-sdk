#ifndef __SIO__H
#define __SIO__H



int OpenChannel(char * comname, int baud);
int CloseChannel(void);
void Wsio(unsigned char cTmp);
unsigned char Rsio(void);
unsigned char RsioStat(char * Stat);
int RsioStat(void);

void ResetCom(void);
void set_baud(int baud);

void reset_DTR(void);
void wsio_str(char * buf, int mode);
void setbreak( void ); 
void clrbreak( void );


void RTS(int mode);
void DTR(int mode);


extern int port_mode;
extern char DEBUG;



extern int toggle_rts;

extern unsigned char ByteSize;
extern unsigned char Parity;
extern unsigned char StopBits;




#define PORT_MODE_SDK   1
#define PORT_MODE_RESET 2



#endif //__SIO__H
