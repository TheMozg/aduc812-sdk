#ifndef __CRC__H
#define __CRC__H

#include <crc8.h>
#include <crc16.h>
#include <crc32.h>

#endif // __CRC__H
