/****************************************************************************

    (C) , 祢 ..  2007 .

 ᢮ ணࠬ;  묮 ⥯୮ ࠭ 쥥 /
஢ 쥥  ᮮ⢥⢨  ᓭᠫ쭮 ⢥
業 GNU, 㡫   ;  ᨨ 2,
 ( 襬 롮)    ᨨ.

 ⠯ணࠬ ࠭  ,  ⮮ 㤥 ⯮,
  - ;   ࠧ㬥 壠࠭⨩
      .  
ﯮ祭 ﯮ஡ ᢥ ᬮ ⥓ᠫ ⢥
業 GNU.

 뤮 뫨  쪮 ᠫ쭮 ⢥ 業
GNU   ⮩ ணࠬ; ᫨ , ⭠ ⥯ : Free
Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
02111-1307 USA

----------------------------------------------------------------------------
㐮, -⏥, ࣪䥤 ࠢ᫨⥫쭮 孨  
e-mail: kluchev@d1.ifmo.ru

****************************************************************************/
#include <stdio.h>
#include <time.h>
#include <sio.h>
#include <ex.h>
#include <termios.h>
#include <sys/signal.h> 
#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <sys/ioctl.h>





clock_t timeout = 20000;

int rs_fd = -1;

static char PortOpen = 0;
int toggle_rts       = 0;

char DEBUG=0;


unsigned char ByteSize = 8;
//unsigned char Parity   = NOPARITY;
//unsigned char StopBits = ONESTOPBIT;


int port_mode = PORT_MODE_RESET;

int OpenChannel(char * comname, int baud)
{
struct termios term;

int current_flag;
struct sigaction action;           //definition of signal action 
int b;


  if(PortOpen) CloseChannel();

   PortOpen=1;  

	if(DEBUG == 2)
    {    
    printf("** DEBUG MODE!\n");
    printf("Note: <xx> - Wsio() byte\n");
    printf("      [xx] - Rsio() byte\n");
    printf("      RTS CONTROL - ENABLE\n");
    printf("      DTR CONTROL - DISABLE\n");
    }
    
    printf("Open channel: %s %d\n", comname, baud );

//	RTS(1);
//  DTR(0);




	if ( rs_fd!=-1 )
        	CloseChannel();




	rs_fd = open(comname ,O_RDWR|O_NOCTTY);
	if ( rs_fd==-1 )
		return 1;


//	fcntl(fd, F_SETFL, FNDELAY); //nonblocking IO 

//	SetTimeout(to);

//	b=B57600;


	switch(baud)
		{
		case 115200: b=B115200; break;
		case 57600:  b=B57600; break;
		case 38400:  b=B38400; break;
		case 19200:  b=B19200; break;
		case 9600:   b=B9600; break;
		case 4800:   b=B4800; break;
		case 2400:   b=B2400; break;
		case 1200:   b=B1200; break;
		}


	bzero(&term, sizeof(term)); 



// -----------------


  bzero(&term, sizeof(term));

  term.c_cflag = B9600 | CS8 | CLOCAL | CREAD; // CRTSCTS | 
  term.c_iflag = IGNPAR;
  term.c_oflag = 0;
  
  term.c_lflag = 0;
   
  term.c_cc[VTIME]    = 100;   
  term.c_cc[VMIN]     = 0;   
  
  tcflush(rs_fd, TCIFLUSH);
  tcsetattr(rs_fd,TCSANOW,&term);
int statusm;
	ioctl(rs_fd, TIOCMGET, &statusm);
	statusm &= ~TIOCM_DTR;  // особенности ранних версий sdk1.1.
	statusm |=  TIOCM_RTS;  //
    ioctl(rs_fd, TIOCMSET, &statusm);
// --------------

    return 0;
}

void set_baud(int baud)
{

}


void ResetCom(void)
{


}

int CloseChannel(void)
{
    if( PortOpen == 0 ) return 0;    

	if(DEBUG == 2)  printf("CloseChannel: \n"); 


	if ( rs_fd!=-1 )
	{
		close(rs_fd);

		rs_fd = -1;
	}


    PortOpen=0;  
    return 0;
}


/*
int rsio(unsigned char *ch)
{
int res;

	if ( read( rs_fd, ch ,1 ) == 1 )
	{
		if ( debug )
			printf("[%02X]",*ch);

		return 0;
	}
	else
		return 1;
}



int wsio(unsigned char ch)
{
	if ( debug ) { printf("{%02X}",ch); fflush(stdout); }

	return (write(rs_fd,&ch,1)!=1);
}

*/


void Wsio(unsigned char cTmp)
{

   if(PortOpen==0)
        {
        printf("** Error! COM port not open...\n");
        return;
        }

	write( rs_fd, &cTmp, 1 );

	if(DEBUG == 2) { printf("<%.2X>",cTmp); fflush(stdout); }
        
}

unsigned char Rsio(void)
{
int res;
unsigned char c;


   if(PortOpen==0)
        {
        printf("** Error! COM port not open...\n"); 
        return 0;
        }


	if ( read( rs_fd, &c ,1 ) == 1 )
	{
		if ( DEBUG == 2)
			printf("[%02X]", c );

		return c;
	}
	else
	{
		throw ex_timeout();
	}


//	if(DEBUG == 2) { printf("[%.2X]",Buf); fflush(stdout); }

        
        return 0;       
    
}

unsigned char RsioStat(char * Stat)
{
int n;

   if(PortOpen==0)
        {
        printf("** Error! COM port not open...\n"); 
        return 0;
        }
	ioctl(rs_fd,FIONREAD,&n);
	if (n) {*Stat = n; return Rsio(); }
	*Stat=0;
        return 0;    
}

int RsioStat(void) //возвращает количество символов в буфере серийного порта
{
	int n;
	if ( rs_fd==-1 )
	{
		perror("Channel wasn't opened");
		return 0;
	}
	ioctl(rs_fd,FIONREAD,&n);
	return n;
}





void RTS(int mode)
{
/*
    switch(mode)
    {
    case 0: EscapeCommFunction( Port, CLRRTS ); break;
    case 1: EscapeCommFunction( Port, SETRTS ); break;

    }
*/
}


void DTR(int mode)
{
/*
    switch(mode)
    {
    case 0: EscapeCommFunction( Port, CLRDTR ); break;
    case 1: EscapeCommFunction( Port, SETDTR ); break;

    }
*/

}


void reset_DTR(void)
{
/*
       EscapeCommFunction( Port, SETDTR );
       Sleep(1000); 
       EscapeCommFunction( Port, CLRDTR );
*/
}

void wsio_str(char * buf, int mode)
{
/*
DWORD  DataLen = 0;
int len;

    if(PortOpen==0)
    {
        cout << "** Error! COM port not open..." << endl;       
        throw ex_timeout();
    }
    len = strlen(buf);

    if( mode )
        buf[len++] = 13;

    WriteFile(Port, buf, len, &DataLen, NULL ); 
*/    

}

void setbreak( void ) { /*SetCommBreak(   Port );*/ printf("Break SET\n");   }
void clrbreak( void ) { /*ClearCommBreak( Port );*/ printf("Break CLEAR\n"); }

