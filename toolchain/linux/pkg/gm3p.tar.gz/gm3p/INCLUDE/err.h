#ifndef __ERR__H
#define __ERR__H

#define OK      0
#define ERR     1


#endif //__ERR__H

