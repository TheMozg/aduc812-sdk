#include <stdio.h>

void Dump(unsigned long Adr,unsigned short N, unsigned char * BASE)
{
int line,col,i;
unsigned char Byte;
unsigned char * _base;
unsigned long l;

          line = N / 16;
          if(N%16) line++;
          if(N < 16) line=1;


          l=(unsigned long)BASE;
          l+=Adr;
          BASE  = (unsigned char *)l;


           for(i=0;i<line;i++)
                {
                printf("\n%.4X.",Adr>>16);
                printf("%.4X ",Adr);

                _base=BASE;

                for(col=0;col<16;col++)
                        {
                        Byte=*_base++;
                        printf("%.2X ",Byte);
                        }

                printf(" ");
                fflush(stdout);

                for(col=0;col<16;col++)
                        {
                        if(*BASE>=32) putchar(*BASE);
                         else putchar('.');
                        BASE++;
                        }
                fflush(stdout);
                Adr +=16;
                }

}












