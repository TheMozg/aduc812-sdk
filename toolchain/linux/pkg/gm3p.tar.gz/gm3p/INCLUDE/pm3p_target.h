#ifndef __PM3P_TARGET__H
#define __PM3P_TARGET__H

#include <sio.h>
#include <err.h>
#include <pm3p_ap.h>

#define AP_NOT_CONNECT         0x40    // ��� ����� (������� ���������)
#define CP_REPEAT              0x81

//������ ����������� ������
#define APE_OK          0x00
#define APE_CMD         0x11
#define APE_PARAM       0x12
#define APE_TRGT        0x13
#define APE_READ        0x30
#define APE_WRITE       0x31
#define APE_ERASE       0x32
#define APE_ACCESS      0x33
#define APE_VERIFY      0x34

#define APE_TRAP        0x77    // ������� ��� ������

//�������
#define APC_GETVERSION  0x1
#define APC_GETBUFSIZE  0x3
#define APC_SETADDR     0x4
#define APC_WRITE       0x5
#define APC_READ        0x6
#define APC_ERASEALL    0x7
#define APC_GETPAGESIZE 0x9
#define APC_ERASESECTOR 0x8
#define APC_JMP         0xC
#define APC_RESETCRC    0xE
#define APC_GETCRC      0xF

//�������������� ����
#define TRGT_MONITOR    0x09
#define TRGT_FLASH      0x34
#define TRGT_TGP        0x60
#define TRGT_RAM        0x41
#define TRGT_FLASH_P    0x35
#define TRGT__RAM_P     0x42


#define DEFAULT_FLASH_SIZEBUF   512
#define MAX_FLASH_SIZEBUF       32768


class PM3P_TARGET  {

protected:

unsigned char current_target;

SYSLOG  log;
PM3P_AP pm3p_ap;

FILE * handle;
unsigned short pagebuf_size;
unsigned long maxlen;       

unsigned char size_in, size_out;
unsigned char version[4];

unsigned char buffer[ 256 ];
unsigned char pagebuf[MAX_FLASH_SIZEBUF];
unsigned char command;
unsigned char error;
unsigned long current_TLA;
int write_ff_enable;      

    int is_ff( unsigned char * buf, long n ); 


    int write_packet( char * name );
    int write_generic( char * name );
    int _write_file( unsigned long maxlen, int add_ff, unsigned long ost );
    int _write_run( void );


public:


    void set( unsigned char target ) { current_target = target; }

    int get_version( void );
    int get_size_buf( void );
    int set_addr( unsigned long TLA );
    int jmp( void );
    int erase_all( void );
    int erase_part( void );
    int write( char * name );
    int read( char * name, unsigned long maxlen );

    int write_buf( unsigned char * buf, int n );
    int read_buf( unsigned char * buf, int n );

    void enable_write_ff( int mode ) { write_ff_enable = mode; }

    int get_size_pagebuf( void );



    PM3P_TARGET() 
    {
        log.init( "pm3p_target.txt" );

        current_TLA     = 0;
        size_in         = 16;
        size_out        = 16;
        write_ff_enable = 0;
    }    

    ~PM3P_TARGET() 
    {

    }
    
};

#endif //__PM3P_TARGET__H

