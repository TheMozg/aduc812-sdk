#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <tabl.h>
#include <textint.h>
#include <stack.h>
#include <forth.h>
#include <word.h>
#include <vocab.h>
#include <ex.h>
#include <ex_error.h>

static char Str[1024];
//static  TAB_LINE TabStr;

unsigned char REM=0;

TAB_LOWLEVEL Exec;



//static void Print(char *Str);
static int IsDigit(char c);
static int Execute(unsigned int Index);


static WORKSTR cws[20];
static int CURRENTWS=0;


char MODE=MODE_EXECUTE;

void textint(void)
{
//int Result;

        printf("\n# ");
        while(1)
                {
				fgets(Str,1024,stdin);
				Str[strlen(Str)-1]=0;
               

                try { Interpret(Str); }
                

                catch (Ex_STACK)    {  f_Abort(); }
                catch (Ex_File)     {  f_Abort(); }
                catch (Ex_MemHeap)  {  f_Abort(); }
                catch (Ex_Redef)    {  f_Abort(); }
                catch (ex_timeout)  {  printf("\nSIO timeout!\n"); f_Abort(); }
                catch (Ex_Param)    {  f_Abort(); }                


                printf("\n# ");
                }
}

void Lfile(unsigned char * Name)
{
FILE * handle;
//int len;

        //if(ABORT) return;

        handle=fopen((char *)Name,"rt"); if(handle==NULL) goto ErrorLfile;
        printf("Open script file %s\n",Name);

        while( fgets(Str,255,handle) )
              {
              try { Interpret(Str); }
              catch (Ex_STACK)   {  f_Abort();
                                    fclose(handle);
                                    return; }
              catch (Ex_PARSING) {  f_Abort();
                                    fclose(handle);
                                    return; }

                catch (Ex_File)     {  f_Abort(); 
                                fclose(handle);
                                    return; }
                catch (Ex_MemHeap)  {  f_Abort(); 
                                    fclose(handle);
                                    return; }
                catch (Ex_Redef)    {  f_Abort(); 
                                    fclose(handle);
                                    return; }

                catch (ex_timeout)  {  printf("\nSIO timeout!\n"); f_Abort(); 
                                    fclose(handle);
                                    return; }

                catch (Ex_Param)    { f_Abort();
                                      fclose( handle );      
                                      return; }            

                catch (ex_error)    { f_Abort();
                                      return; }            
                        


              Str[0]=0;
              }



        fclose(handle);
        return;

ErrorLfile:
        printf("\n** Error! File %s not found...",Name);
}



void Print(char *Str)
{

       while(*Str) putchar(*Str++);

}

unsigned char * NextWord(void)
{
WORKSTR *ws;

        ws=&cws[CURRENTWS];

        return Word(ws,0x20);
}

unsigned char * NextWordD(unsigned char Delimiter)
{
WORKSTR *ws;

        ws=&cws[CURRENTWS];

        return Word(ws,Delimiter);
}


void Upper(char * Str)
{
        while(*Str)
                {
                *Str=toupper(*Str);
                Str++;
                }
}


int Interpret(char * Str)
{
unsigned long iTmp,index;
unsigned char *w;
WORKSTR *ws;
int Res;

        if(++CURRENTWS >20)
                {
                printf("\nInterpret: СЛИШКОМ БОЛЬШАЯ ВЛОЖЕННОСТЬ!");
                Bye();
                }

        ws=&cws[CURRENTWS];

        NewString(ws,(unsigned char *)Str);

        Res=0;
        while(w=Word(ws,0x20))
                {
                Upper((char *)w);
                if( TestDigit((char *)w,&iTmp) == 1 )
                        {
                        if(MODE==MODE_EXECUTE)
                                StackData.push(iTmp);
                         else
                                {
                                //LIT
                                StoreWord((int)W_LIT);
                                StoreWord((int)iTmp);
                                }
                                
                                
                        }
                 else
                        {
                        if( index=Find(w) )
                                {
                                if(MODE==MODE_EXECUTE)
                                        {
                                        if(Execute(index))
                                                {
                                                Res=0;  // ਩   ப
                                                break;
                                                }
                                        }
                                 else
                                        {
                                        if( Exec.Flag[index] & IMMEDIATE )
                                                {
                                                if(Execute(index))
                                                        {
                                                        Res=0;  // ਩   ப
                                                        break;
                                                        }
                                                }
                                         else
                                                StoreWord((unsigned short)index);
                                        }
                                }
                         else
                                {
                                printf("\n %s - неизвестная команда",w);

                                Res=2;
                                break;
                                }
                         }


                }
        --CURRENTWS;
        return Res;
}

/*
int ExecuteV(int cfa)
{
int index;
int current;
int mark=0;
int count=0;
        current=cfa;

        while(1)
        {   
            index=GetWord(current);


            switch(index)
            {
            case W_MARK:    StackReturn.push(current);  
                            current+=sizeof(int);
                            break;
            case W_BRANCH:  current=StackReturn.pop();
                            break;
            case W_EXIT:    return 0;
            case W_LIT:     current+=sizeof(int);
                            index=GetWord(current);
                            current+=sizeof(int);
                            StackData.push(index); break;
            default:        Execute(index); 
                            current+=sizeof(int);
                            //if(count++ > 10) return 0;
                            break;
            }

        

        
        }
                
}
*/
/*
-------------   ----------------------------------

JMP_F       // (JMP if false)
JMP_T       // (JMP if true)
Store(x)    //  X  

------------------- --------------------
              
------------------- --------------------

1. BEGIN AGAIN


Addr:               BEGIN   push(Here)
    ---
    ---
    ---
    JMP             AGAIN   Store(JMP)
    Addr                    Addr=pop() Store(Addr)


2. IF THEN

    JMP_F           IF      Store(JMP_F)
    Addr                    push(Here) Store(0) 
    ---
    ---
    ---
Addr:               THEN    Addr=pop();
    ---                     [Addr]=Here;
    
3. IF ELSE THEN

    JMP_F           IF      Store(JMP_F)
    Addr                    push(Here) Store(0) 
    ---
    ---
    ---
    JMP             ELSE    
    Exit                    Store(JMP)  
Addr:                       push(Here) Store(0)
    ---                     swap() Addr=pop(); [Addr]=Here;
    ---
    ---
Exit:                       Addr=pop();
                            [Addr]=Here

4. DO LOOP

    
Addr:
    CMP Count,0
    JMP_T   
    Exit
    DEC Count
    ---
    ---
    ---
    ---
    ---
    JMP 
    Addr
Exit:


5. BEGIN WHILE REPEAT


Addr:               BEGIN   push(Here)
    ---
    ---
    ---
    ---
    JMP_F           WHILE   Store(JMP_F)
    Exit                    push(Here) Store(0)                 
    ---                     
    ---
    ---
    JMP             REPEAT  Store(JMP)
    Addr                    swap() Addr=pop() Store(Addr)
Exit:                       Addr=pop(); [Addr]=Here;

6. BEGIN UNTIL


Addr:               BEGIN   push(Here)
    ---
    ---
    ---
    JMP_F               UNTIL   Store(JMP_F)
    Addr                        Addr=pop() Store(Addr)



*/

int ExecuteV(int cfa)
{
int index;
int current;
int SP;
int i,Addr;
// == for cycle DO LOOP ==
int Count;
int N;
// == end DO ==


        SP=StackReturn.getsp();

        StackReturn.push(cfa);

        while(1)
        {   
            current=StackReturn.get();
            index=GetWord(current);


            switch(index)
            {
/*
            case W_BEGIN:   
                            StackReturn.push(current);  
                            current+=sizeof(int);
                            StackReturn.put(current);
                            break;

            case W_AGAIN:   current=StackReturn.pop();
                            StackReturn.put(current);
                            break;
*/
/*
Addr:               BEGIN   push(Here)
    ---
    ---
    ---
    JMP             AGAIN   Store(JMP)
    Addr                    Addr=pop() Store(Addr)
*/
            case W_JMP:     current+=sizeof(int);
                            current=GetWord(current);
                            StackReturn.put(current);
                            break;

/*
    JMP_F           IF      Store(JMP_F)
    Addr                    push(Here) Store(0) 
    ---
    ---
    ---
Addr:               THEN    Addr=pop();
    ---                     [Addr]=Here;
*/
            case W_JMP_F:   if( StackData.pop()==0)
                                {
                                current+=sizeof(int);
                                current=GetWord(current);
                                StackReturn.put(current);
                                }
                             else
                                {
                                current+=sizeof(int);
                                current+=sizeof(int); // +Addr
                                StackReturn.put(current);
                                }
                            break;
            case W_JMP_T:   if( StackData.pop()!=0)
                                {
                                current+=sizeof(int);
                                current=GetWord(current);
                                StackReturn.put(current);
                                }
                             else
                                {
                                current+=sizeof(int);
                                current+=sizeof(int); // +Addr
                                StackReturn.put(current);
                                }
                            break;
            case W_EXIT:    
            case W_RETURN:
                            StackReturn.drop();
                            if(SP!=StackReturn.getsp())
                                {
                                printf("** Error! Problem with stack of return's!\n"); 
                                throw Ex_PARSING();
                                }
                            return 0;

            case W_LIT:     current+=sizeof(int);
                            index=GetWord(current);
                            current+=sizeof(int);
                            StackData.push(index); 
                            StackReturn.put(current);
                            break;
            case W_LIT_STR: current+=sizeof(int);
                            StackData.push(current);
                            index=GetWord(current); // n
                            current+=sizeof(int);
                            current+=index;         // Str
                            StackReturn.put(current);
                            break;

            case W_LIT_STR_PRINT:
                            current+=sizeof(int);
                            //StackData.push(current);
                            index=GetWord(current); // n
                            current+=sizeof(int);
                            Addr=current;
                            current+=index;         // Str
                            StackReturn.put(current);

                            for(i=0;i<index;i++)
                                {
                                StackData.push(GetByte(Addr++));
                                f_emit();
                                
                                }
                            fflush(stdout);
                            break;


            case W_CURRENT_ADDR:
                            StackReturn.drop();
                            StackData.push(current+=sizeof(int) );
                            return 0;

            case W_CURRENT_VALUE:
                            StackReturn.drop();
                            index=GetWord( current+=sizeof(int) );
                            StackData.push(index);
                            return 0;

            case W_PUSH_COUNT:
                            StackData.push(Count);
                            current+=sizeof(int);
                            StackReturn.put(current);
                            break;

            case W_POP_COUNT:
                            Count=StackData.pop();
                            current+=sizeof(int);
                            StackReturn.put(current);
                            break;

            case W_PUSH_N:
                            StackData.push(N);
                            current+=sizeof(int);
                            StackReturn.put(current);
                            break;

            case W_POP_N:
                            N=StackData.pop();
                            current+=sizeof(int);
                            StackReturn.put(current);
                            break;

            case W_COMPARE:
                            if(Count >= N) StackData.push(-1); else StackData.push(0);
                            current+=sizeof(int);
                            StackReturn.put(current);
                            break;

            case W_COUNT_INC:
                            Count++;            
                            current+=sizeof(int);
                            StackReturn.put(current);
                            break;

            default:        Execute(index); 
                            current+=sizeof(int);
                            StackReturn.put(current);
                            //if(count++ > 10) return 0;
                            break;
            }

        

        
        }

}


int Execute(unsigned int Index)
{
//void (*f)(void);

//      if(Index==1)
//              return 1;       // quit

        if(Exec.CFA[Index]==0)
                {

                Exec.f[Index]();
                //f();
                }
         else
                {
                ExecuteV(Exec.CFA[Index]);
                }

        if(REM)
                {
                REM=0;
                return 1;
                }

        return 0;
}


unsigned int Find(unsigned char *Name)
{
unsigned int i;

        for(i=1;i<(unsigned int)Exec.N+1;i++)
                {
                if(strcmp((char*)Name,(char *)Exec.Name[i])==0)
                        return i;
                }
        return 0;
}


unsigned long TestDigit(char * Str, unsigned long *iTmp)
{
 char *cTmp;
long dType = 0xffff;
int i=0;

        if(strlen(Str)==0)
                return 0;

        cTmp=Str;
        if(IsDigit(*cTmp)==1) return 0;
        if(*cTmp=='0')
                if( (*(cTmp+1)=='X') || (*(cTmp+1)=='x') ) { dType&=1; cTmp+=2; }
        else
                while(*(cTmp+i))
                   if( (*(cTmp+i)=='H') || (*(cTmp+i)=='h')) { *(cTmp+i)=0; dType&=1; }
                   else i++;
        i=0;
        while(*(cTmp+i))
                {
                dType&=IsDigit(*(cTmp+i++));
                if(dType==0) return 0;
                }
        if(dType==1) sscanf(cTmp,"%lx",iTmp);
         else if(dType==3) sscanf(cTmp,"%li",iTmp);
                else return 0;
        return 1;
}

int IsDigit(char c)
{
if((c>='a'&&c<='f') || (c>='A'&&c<='F')) return 1;
if(c>='0'&&c<='9') return 3;
return 0;
}


void AddFunc( void (*f)(void), unsigned char *Name, unsigned char Type, char Immediate)
{
char s[255];

    strcpy(s, (char*)Name);

    Upper(s);

    if(Find((unsigned char *)s)) 
            { 
                printf("Word %s already exist...\n", Name ); 
                throw Ex_Redef();
            }
    

        if(Exec.N==0) Exec.N=1; else Exec.N++;

        if(Exec.N > TabLLen)
                {
                printf("\n\nERROR: (AddFunc) overflow!");
                Bye();

                }

        Exec.CFA[Exec.N]=0;
        Exec.f[Exec.N]=f;
        Exec.Flag[Exec.N]=1;
        if(Immediate) Exec.Flag[Exec.N] |= 2;


        Exec.Type[Exec.N]=Type;

        strcpy((char *)&Exec.Name[Exec.N],s);

}



void AddNewFunc(unsigned short CFA, unsigned char *Name, unsigned char Type, char Immediate)
{
char s[255];

    strcpy(s, (char*)Name);

    Upper(s);

    if(Find( (unsigned char *)s ) )
            { 
                printf("Word %s already exist...\n", Name );
                throw Ex_Redef();
            }



        if(Exec.N==0) Exec.N=1; else Exec.N++;

        if(Exec.N > TabLLen)
                {
                printf("\n\nERROR: (AddFunc) Overflow of function table!");
                Bye();

                }

        Exec.CFA[Exec.N]=CFA;
        Exec.f[Exec.N]=NULL;
        Exec.Flag[Exec.N]=1;
        if(Immediate) Exec.Flag[Exec.N] |= 2;        


        Exec.Type[Exec.N]=Type;

        strcpy((char *)&Exec.Name[Exec.N],s);

}


void InterpretDigit(char * Str,I_DIGIT * idig)
{
unsigned int iTmp;
unsigned char *w;
WORKSTR *ws;
int Res;


        idig->N=0;

        if(++CURRENTWS >20)
                {
                printf("\nInterpret: СЛИШКОМ БОЛЬШАЯ ВЛОЖЕННОСТЬ!");
                Bye();
                }

        ws=&cws[CURRENTWS];

        NewString(ws,(unsigned char *)Str);

        Res=0;
        while(w=Word(ws,0x20))
                {
                Upper((char *)w);
                if( TestDigit((char *)w,(unsigned long *)&iTmp)==1 )
                        {
                        //cprintf("  %d \r\n",iTmp);
                        idig->iVal[idig->N++]=iTmp;
                        if(idig->N >80)
                                {
                                printf("\n Слишком много чисел! ");
                                Res=2;
                                break;
                                }


                        }
                 else
                        {
                        printf("\n %s - не цифра!",w);
                        Res=2;
                        break;
                        }



                }
        --CURRENTWS;
 //       return Res;
}




