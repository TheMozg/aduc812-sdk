#ifndef __PROGRESS__H
#define __PROGRESS__H

void ShowPercent(FILE * handle, int max, int value);
int GetNline(char * filename);

#endif // __PROGRESS__H


