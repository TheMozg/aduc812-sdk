#include <stdio.h>
#include <string.h>
#include <word.h>




unsigned char * Word(WORKSTR * ws, unsigned char Delimiter);
void NewString(WORKSTR * ws, unsigned char *Str);




/*
void main(void)
{
unsigned char Str[]={"          test0 test1 test2 test3( test4 test5 )  "};
unsigned char * s;
WORKSTR ws;



        NewString(&ws,Str);

          s=Word(&ws,0x20);     printf("\n%s",s);
}
*/

void NewString(WORKSTR * ws, unsigned char *Str)
{
        ws->Str=Str;
        ws->Pos=0;
        DestructControl(ws->Str);
        ws->Len=strlen((char *)ws->Str);
}

void DestructControl(unsigned char * s)
{

        while(*s)
                {
                if(*s<0x20) *s=0x20;
                s++;
                }

}

unsigned char * Word(WORKSTR * ws, unsigned char Delimiter)
{
unsigned char *Beg;
int i;
//char BadDelim=1;

        if(ws->Pos >= ws->Len)
                {
                //cout << "**Error #1 delimiter! " << endl;    
                return (unsigned char * )0L;
                }

        for(i=ws->Pos; i<ws->Len; i++)
                {
                if(ws->Str[i] != 0x20) break;
                ws->Pos++;
                }

        if(ws->Pos >= ws->Len)
                {
                //cout << "**Error #2 delimiter! " << endl;
                return (unsigned char * )0L;
                }

        Beg=&ws->Str[ws->Pos];


        for(i=ws->Pos; i<ws->Len; i++)
                {
                ws->Pos++;
                if(ws->Str[i] == Delimiter)
                         {
                         ws->Str[i]=0;
                         //BadDelim=0;
                         break;
                         }
                }

//                if(BadDelim)
//                        {
//                            cout << "**Error delimiter! " << endl;
//                            ws->Str[i]=0;
//                        }

        return Beg;



}



