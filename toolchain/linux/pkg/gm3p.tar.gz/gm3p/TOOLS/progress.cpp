/****************************************************************************

    (C) , 祢 ..  2007 .

 ᢮ ணࠬ;  묮 ⥯୮ ࠭ 쥥 /
஢ 쥥  ᮮ⢥⢨  ᓭᠫ쭮 ⢥
業 GNU, 㡫   ;  ᨨ 2,
 ( 襬 롮)    ᨨ.

 ⠯ணࠬ ࠭  ,  ⮮ 㤥 ⯮,
  - ;   ࠧ㬥 壠࠭⨩
      .  
ﯮ祭 ﯮ஡ ᢥ ᬮ ⥓ᠫ ⢥
業 GNU.

 뤮 뫨  쪮 ᠫ쭮 ⢥ 業
GNU   ⮩ ணࠬ; ᫨ , ⭠ ⥯ : Free
Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
02111-1307 USA

----------------------------------------------------------------------------
㐮, -⏥, ࣪䥤 ࠢ᫨⥫쭮 孨  
e-mail: kluchev@d1.ifmo.ru

****************************************************************************/
#include <stdio.h>
#include <ex.h>
#include <progress.h>
#include <hexbin.h>
#include <string.h>

#define sizebar 5

void Bar(FILE * handle,int percent)
{
int i,j,n;
    
    fprintf(handle,"[%3d",percent); fprintf(handle,"%c",(char)37);
    fprintf(handle,"][");
    
    if(percent==0) 
        {
        n=0;
        }   
     else
        {
         n=percent/sizebar;
         if(percent<100)
            {   
            if(percent%sizebar) n++;
            }

        }
    
    for(i=0;i<n;i++) fprintf(handle,"#");

    for(j=0;j<(100/sizebar-i);j++)     fprintf(handle,".");
    fprintf(handle,"]");
    fflush(handle);
}

void ShowPercent(FILE * handle, int max, int value)
{
int beg=0;
int persent=0;

    if(value==0) 
        { Bar(handle,0); }
     else
        {
         Bar(handle, (value*100)/max);
        }

}



int GetNline(char * filename)
{
char Str[128];
int count;
FILE * handle;

    
    if(filename==NULL) { printf("Argument not found!\n"); /*throw Ex_Param();*/ }

    handle=fopen(filename,"rb"); 
    if(handle==NULL) 
    {   
        printf("File not found!\n"); 
        fflush(stdout); 
        //throw Ex_File();
    }

    count=0;
    while(1)
    {
        Str[0]=0;
        fgets((char *)Str,100,handle);
        if(strlen((char *)Str)==0) break;
        if(Str[0]!=':') break;
        if(GetHexCom((unsigned char *)Str) != 0) break;     
        ++count;

    }

    fclose(handle);
    return count;   
}
