#ifndef __DUMP__H
#define __DUMP__H

void Dump(unsigned long Adr,unsigned short N, unsigned char  * BASE);

#endif // __DUMP__H

