#ifndef __VOCAB__H
#define __VOCAB__H

#define VS  65536

extern unsigned char Vocabulary[VS];    // R/O ᫮����
extern unsigned short Here;     // R/O Here == 2 !!!


// ����� � ᫮��६

extern void StoreWord(unsigned int word);
extern void StoreByte(unsigned char byte);
extern void StoreString(unsigned char * S);
extern void Create(unsigned char * Name);
extern void Compile(unsigned char * Name);

extern int GetWord(int Addr);
extern unsigned char GetByte(int Addr);

#endif // __VOCAB__H
