#include <stdio.h>
#include <string.h>
#include <tabl.h>
#include <textint.h>
#include <stack.h>
#include <forth.h>
#include <word.h>
#include <vocab.h>






unsigned char Vocabulary[VS];   // R/O �������
unsigned short Here=2;          // R/O Here == 2 !!!

// ������ �� ��������

int GetWord(int Addr)
{
unsigned int * iTmp;

    iTmp=(unsigned int *)&(Vocabulary[Addr]);
    return *iTmp;

}

unsigned char GetByte(int Addr)
{
unsigned char * cTmp;

    cTmp=(unsigned char *)&(Vocabulary[Addr]);
    return *cTmp;

}


void StoreWord(unsigned int word)
{
unsigned int * iTmp;



        if( (Here + 2) < VS )
                {
                iTmp=(unsigned int *)&Vocabulary[Here];
                *iTmp=word;
                Here+=sizeof(int);
                }



}


void StoreByte(unsigned char byte)
{

        if( (Here + 1) < VS) Vocabulary[Here++]=byte;

}


void StoreString(unsigned char * S)
{
unsigned short Len;

        Len=strlen((char *)S);

        if(Len == 0) return;
        if(Len >= (VS-Here+3) ) return;

        StoreWord(Len);
        strcpy((char *)&Vocabulary[Here],(char *)S);
        Here+=Len;
}




void Create(unsigned char * Name)
{


//        AddNewFunc(Here, Name, T_USER);


}

void Compile(unsigned char * Name)
{

}

