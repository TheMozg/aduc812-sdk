#ifndef __FORTH__H
#define __FORTH__H

void Words(void);
void Abort(void);
void Words(void);
void Bye(void);
void Plus(void);
void Point(void);
void _Init(void);
void f_Abort(void);


extern char ABORT;


extern char Buf[128];
extern char ECH0;
void f_emit(void);
void f_echooff(void);
void EmitStr(char * Str);
void emit(char c);

#endif // __FORTH__H




