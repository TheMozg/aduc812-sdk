//#include <WINDOWS.h>
#include <terminal.h>

#include <kbhit.h>
#include <forth.h>
#include <stdio.h>
///#include <conio.h>
#include <time.h>
#include <iostream>
#include <sio.h>

#include <fstream>
#include <sys/types.h>                     //
#include <sys/stat.h>                      //   C library
#include <fcntl.h>                         //
#include <time.h>                       //
#include <errno.h>
#include <crc8.h>

#include <hexbin.h>
#include <progress.h>
#include <tabl.h>
#include <textint.h>
#include <ex.h>
#include <stack.h>

typedef unsigned char BYTE;

using namespace std;
void Terminal(int Mode) // 0 Bin, 1 Hex, 2 Dump
{
BYTE bTmp;
char Stat;
int count=0;
BYTE Buf[16];
char cTmp;
keyboard kb;
//clock_t old_timeout = timeout;
char s[80];




        cout << "TERM on in ";
        switch(Mode)
                {
                case 0: cout << "Bin ";     break;
                case 1: cout << "Hex ";     break;
                case 2: cout << "Dump ";    break;
                case 3: cout << "Mterm ";   break;
                case 4: cout << "<CR> ";    break;
                case 5: cout << "<CR>\\n "; break;
                case 6: cout << "tstamp ";  break;

                default: cout << "\nMode error!\n"; goto ErrorTerminal;
                }

        cout << "mode..." << endl;

    //    if( Mode == 6 ) show_tstamp();

        while(1)
                {
                bTmp=RsioStat(&Stat);
                if(Stat)
                        {
                        switch(Mode)
                                {
                                    case 0: printf("%c",bTmp); fflush(stdout); break;
                                    case 1: sprintf(s, "%.2X ",bTmp); EmitStr( s ); /* fflush(stdout); */ break;
                                    case 2: if(count >15)
                                                {
                                                for(int i=0;i<16;i++) emit(Buf[i]);
                                                count = 0;
                                                sprintf(s, "\n"); EmitStr( s );
                                                }
                                              else
                                                {
                                                if(count == 8) emit(32);

                                                sprintf(s, "%.2X ",bTmp); EmitStr( s );
                                                if(bTmp < 0x20)
                                                        Buf[count++] = '.';
                                                 else
                                                        Buf[count++]=bTmp;
                                                fflush(stdout);
                                                }
                                                break;
                                    case 3: /*multiterm(bTmp, 0, 0);*/ break;
                                    case 4: if( bTmp == 13)
                                            {
                                                EmitStr( "<CR>" );
                                            }
                                            else
                                                {
                                                    sprintf(s, "%c",bTmp);
                                                    EmitStr( s );
                                                }

                                                break;

                                    case 5: if( bTmp == 13)
                                            {
                                                EmitStr("<CR>\n");
                                            }
                                            else
                                            {
                                                sprintf(s, "%c",bTmp);
                                                EmitStr( s );

                                            }
                                            break;
                                    case 6: /*multiterm(bTmp, 0, 1); */ break;

                                }
                        }
                 if(kb.kbhit())
                        {
                        cTmp=kb.getch();
                        if(cTmp==27) goto ExitTerminal;
                        Wsio((BYTE)cTmp);
                        }
                }


ErrorTerminal:
ExitTerminal:
        printf("\nTERM off\n");

      //  timeout = old_timeout;

   /* multiterm(0,1, 0); */

}

