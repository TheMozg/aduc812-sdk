#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <time.h>

#include <tabl.h>
#include <textint.h>
#include <stack.h>

#include <ex.h>
#include <forth.h>
#include <word.h>
#include <vocab.h>
#include <dump.h>
#include <sio.h>
#include <crc8.h>
#include <pm3p_target.h>
#include <hb166.h>
#include <mkdate.h>
#include <terminal.h>
#include <gdownload.h>

PM3P_TARGET pm3p;


static unsigned char ExitOnError=0;
static bool TEST=0;


//static int  CurrentTarget=0;    

//int write_ff = 0;       // =1    FF  target

/*
#define COMMAND_READ        1   
#define COMMAND_WRITE       2
#define COMMAND_ERASEPART   3   //  
#define COMMAND_ERASEALL    4       //  
#define COMMAND_JMP     5
*/

void f_write_ff(void)
{
int write_ff = StackData.pop();

    pm3p.enable_write_ff( write_ff );

    if( write_ff )
        printf("Write 0xFF ON\n");
    else
        printf("Write 0xFF OFF\n");
}

void CheckExit(void)
{
    if(ExitOnError)
    {

        printf("** Terminate M3P.\n"); 
        Bye();
    }
}


void f_Terminal(void)
{
    Terminal(StackData.pop());
}    


void f_Lfile(void)
{
    Lfile(NextWord());
}

void f_DEBUG(void)
{
    DEBUG=StackData.pop();
}


void f_OpenChannel(void)
{
char * comname;
int baud;
char sbuf[80];

    comname = (char *)NextWord();
    baud    = StackData.pop();

    sprintf( sbuf, "M3P %s, %d bit/sec", comname, baud);

    OpenChannel(comname,baud);
}

void f_OpenCom2(void)
{
        OpenChannel("com2",57600);
}

void f_OpenCom1(void)
{
        OpenChannel("com1",57600);
}

void f_RTS(void)
{
    RTS( StackData.pop() );
}

void f_RTS_TOGGLE(void)
{
    toggle_rts = StackData.pop(); 
}

void f_setbaud(void)
{
    set_baud( StackData.pop() );
}


void f_DTR(void)
{
    DTR( StackData.pop() );
}

void f_reset_DTR(void)
{
    reset_DTR();
}

void f_PORT_MODE(void)
{
    port_mode = StackData.pop();
}


void f_CloseChannel(void)
{
    

    CloseChannel();
}

void f_TestON(void)
{
    printf("** TEST mode ON\n"); 
    TEST=1;        
}

void f_TestOFF(void)
{
    printf("** TEST mode OFF\n");
    TEST=0;       
}


void f_Stat(void)
{
    if(DEBUG) 
        printf("DEBUG = ON\n");
     else
        printf("DEBUG = OFF\n");
     if(TEST)
        printf("TEST  = ON\n");
     else
        printf("TEST  = OFF\n");
}







void f_Rsio(void)
{
        StackData.push(Rsio());
}

void f_Wsio(void)
{
        Wsio(StackData.pop());
}


void f_WsioStr(void)
{
char * Str;

    Str = (char *)NextWordD('"');

    if(Str == NULL) return;

    wsio_str( Str, 1 );
}


void f_WsioStrStack(void)
{
char Str[80];
int n;
int i;

    n = StackData.pop();

printf("%d ",n);

    if(n > 79) 
    {
        printf("n > 80! \n");
        return;
    }

    i = n - 1;

    while(1)
    {
        Str[i] = StackData.pop(); 

        if( i == 0) break;
        i--;
    }

    Str[n] = 0;

    wsio_str( Str, 1 );
}






void f_TerminateOnError(void)
{
    ExitOnError=1;
}








void f_ctime(void)  
{
int i,n;
        unsigned long ltime = StackData.pop();
        sprintf(Buf, "%s", ctime( (long *)&ltime ) );   
        n=strlen(Buf);

        for(i=0;i<n;i++)
            {
            if(Buf[i]==10) Buf[i]=0;
            if(Buf[i]==13) Buf[i]=0;
            }
        
        EmitStr(Buf);

}






void f_char( void )
{
unsigned char * name;
    
    name = NextWord();

    if(name == NULL) printf("** Error! Invalid char! \n");

    if( MODE == MODE_EXECUTE )
        StackData.push( name[0] );
    else
    {
        printf("** Error! invalid mode, need execution.\n");
        f_Abort();                                         
    }        

}


void f_char1( void )
{
unsigned char * name;
    
    name = NextWord();

    if(name == NULL) printf("** Error! Invalid char! \n");

    if( MODE == MODE_EXECUTE )
    {
        printf("** Error! invalid mode, need compilation.\n");
        f_Abort();                                         
    }        
    else
    {
        StoreWord((int)W_LIT);
        StoreWord(name[ 0 ]);
    }

}

void purge_sio( void )
{
char Stat;

    while(1)
    {
        RsioStat(&Stat);
        if(Stat == 0) break;
    }    
}

void f_evenparity( void ) {  /*Parity = EVENPARITY;*/ }
void f_noparity( void )    { /*Parity = NOPARITY;*/ }
void f_oddparity( void )   { /*Parity = ODDPARITY;*/ } // 

void f_7bit( void )        { ByteSize = 7; } 
void f_8bit( void )        { ByteSize = 8; } 

void f_1stop( void )       { /*StopBits = ONESTOPBIT;*/ } 
void f_15stop( void )      { /*StopBits = ONE5STOPBITS;*/ } 
void f_2stop( void )       { /*StopBits = TWOSTOPBITS;*/ } 



// --------------------------------------------------------------------------
//                               PM3P
// --------------------------------------------------------------------------


void f_t_ram(   void )     { pm3p.set( TRGT_RAM     );   printf("TARGET = RAM\n");   }
void f_t_flash( void )     { pm3p.set( TRGT_FLASH   );   printf("TARGET = FLASH\n"); }
void f_t__ram_p(   void )  { pm3p.set( TRGT__RAM_P  );   printf("TARGET = _RAM_P\n");   }
void f_t_flash_p( void )   { pm3p.set( TRGT_FLASH_P );   printf("TARGET = FLASH_P\n"); }

void f_t_set(   void ) 
{
unsigned char target = StackData.pop();

    pm3p.set( target ); printf("TARGET = 0x%.2X\n", target);
}

void f_jmp( void ) // addr ->
{
unsigned long TLA = StackData.pop();

    printf("JMP 0x%.8lX\n", TLA);
    
    if( ERR == pm3p.set_addr( TLA ) )   f_Abort();
    if( ERR == pm3p.jmp()           )   f_Abort();
}



void f_erase_part( void ) // addr ->
{
unsigned long TLA = StackData.pop();

    printf("ERASE SECTOR 0x%.8lX\n", TLA);


    if( ERR == pm3p.set_addr( TLA ) ) f_Abort();
    if( ERR == pm3p.erase_part()    ) f_Abort();
}

void f_erase_all( void )
{
    printf("ERASE ALL\n");

    if( ERR == pm3p.erase_all() ) f_Abort();
}

void f_write( void ) // addr ->
{
unsigned char * name;
unsigned long TLA = StackData.pop();
    
    name = NextWord();

    if(name == NULL) 
    {
        printf("** Error! Invalid name! \n");
        f_Abort();                                         
    }

    printf("WRITE 0x%.8lX\n", TLA);


    if( ERR == pm3p.set_addr( TLA ) ) f_Abort();
    if( ERR == pm3p.write( (char *)name )   ) f_Abort();
}




void f_download( void ) // addr ->
{
unsigned char * name;
//unsigned long TLA = StackData.pop();
    
    name = NextWord();

    if(name == NULL) 
    {
        printf("** Error! Invalid name! \n");
        f_Abort();                                         
    }

  //  printf("WRITE 0x%.8lX\n", TLA);

	gdownload((char*)name);
    //if( ERR == pm3p.set_addr( TLA ) ) f_Abort();
    //if( ERR == pm3p.write( (char *)name )   ) f_Abort();
}



void f_write_byte( void ) // addr, byte ->
{
unsigned char value; 
unsigned long TLA; 
    
    value = StackData.pop();
    TLA   = StackData.pop();

    printf("WRITE_BYTE 0x%.8lX, 0x%.2X\n", TLA, value);

    if( ERR == pm3p.set_addr( TLA ) )        f_Abort();
    if( ERR == pm3p.write_buf( &value, 1 ))  f_Abort();
}

void f_write_word( void ) // addr, word ->
{
unsigned short value; 
unsigned long TLA; 
unsigned char x[2];
    
    value = StackData.pop();
    TLA   = StackData.pop();

    x[ 0 ] = value;
    x[ 1 ] = value >> 8;

    printf("WRITE_WORD 0x%.8lX, 0x%.4X\n", TLA, value);

    if( ERR == pm3p.set_addr( TLA ) )        f_Abort();
    if( ERR == pm3p.write_buf( x, 2 ))       f_Abort();
}

void f_write_dword( void ) // addr, dword ->
{
unsigned long value; 
unsigned long TLA; 
unsigned char x[4];
    
    value = StackData.pop();
    TLA   = StackData.pop();

    x[ 0 ] = value;
    x[ 1 ] = value >> 8;
    x[ 2 ] = value >> 16;
    x[ 3 ] = value >> 24;

    printf("WRITE_DWORD/WRITE_FLOAT 0x%.8lX, 0x%.8X\n", TLA, value);

    if( ERR == pm3p.set_addr( TLA ) )        f_Abort();
    if( ERR == pm3p.write_buf( x, 4 ))       f_Abort();
}

void f_read_byte( void ) // addr -> value
{
unsigned long TLA;
unsigned char x;
    

    TLA = StackData.pop();


    if( ERR == pm3p.set_addr( TLA ) ) f_Abort();
    if( ERR == pm3p.read_buf( &x, 1 ) )   f_Abort();

    printf("READ_BYTE 0x%.8lX, 0x%2X\n", TLA, x);
    
    StackData.push( x );

}


void f_read_word( void ) // addr -> value
{
unsigned long TLA;
unsigned char x[2];
unsigned short value;
    

    TLA = StackData.pop();


    if( ERR == pm3p.set_addr( TLA ) ) f_Abort();
    if( ERR == pm3p.read_buf( x, 2 ) )   f_Abort();

    value =  x[ 1 ]; value <<= 8;
    value |= x[ 0 ];

    printf("READ_WORD 0x%.8lX, 0x%4X\n", TLA, value);
    
    StackData.push( value );

}


void f_read_dword( void ) // addr -> value
{
unsigned long TLA;
unsigned char x[4];
unsigned long value;
    

    TLA = StackData.pop();


    if( ERR == pm3p.set_addr( TLA ) ) f_Abort();
    if( ERR == pm3p.read_buf( x, 4 ) )   f_Abort();

    value =  x[ 3 ]; value <<= 8;
    value |= x[ 2 ]; value <<= 8;
    value |= x[ 1 ]; value <<= 8;
    value |= x[ 0 ];

    printf("READ_DWORD/ READ_FLOAT 0x%.8lX, 0x%.8X\n", TLA, value);
    
    StackData.push( value );
}


void f_read( void ) // addr, len ->
{
unsigned char * name;
unsigned long len;
unsigned long TLA;
    
    name = NextWord();

    if(name == NULL) 
    {
        printf("** Error! Invalid name! \n");
        f_Abort();                                         
    }

    len = StackData.pop();
    TLA = StackData.pop();

    printf("READ 0x%.8lX, %d\n", TLA, len);


    if( ERR == pm3p.set_addr( TLA ) ) f_Abort();
    if( ERR == pm3p.read( (char * )name, len ) ) f_Abort();
}


void f_pm3p_test( void ) 
{ 
//    pm3p.get_size_buf(); 

    pm3p.set( TRGT_FLASH );

    pm3p.set_addr( 0xF90000 );
//    pm3p.set_addr( 0xF90000 );

    pm3p.read("test.bin", 2000 );

}

/* --------------------------------------------------------------------------
		㭪樨  HEX -> BIN ८ࠧ
-------------------------------------------------------------------------- */



void f_hb166(void)
{
unsigned char *name1,*name2;


    name1 = NextWord();
    name2 = NextWord();

    if( (name1 == NULL) || (name2 == NULL) )
    {
        printf("** Error! Invalid name! \n");
        f_Abort();                                         
    }


        hb16(name1, name2);
}


void f_hb64(void)
{
unsigned char *name1,*name2;
unsigned short addr_b, fragment_len;

    fragment_len = StackData.pop();
    addr_b       = StackData.pop();

    name1 = NextWord();
    name2 = NextWord();

    if( (name1 == NULL) || (name2 == NULL) )
    {
        printf("** Error! Invalid name! \n");
        f_Abort();                                         
    }


        hb64(addr_b, fragment_len, name1, name2);
}

//void hb_fragment32(unsigned long addr_b, unsigned long fragment_len, unsigned char * NameIn, unsigned char * NameOut)

void f_hb_fragment32(void)
{
unsigned char *name1,*name2;
unsigned long addr_b, fragment_len;

    fragment_len = StackData.pop();
    addr_b       = StackData.pop();

    name1 = NextWord();
    name2 = NextWord();

    if( (name1 == NULL) || (name2 == NULL) )
    {
        printf("** Error! Invalid name! \n");
        f_Abort();                                         
    }


        hb_fragment32(addr_b, fragment_len, name1, name2);
}





void f_hb32(void)
{
unsigned char *name1,*name2;

    name1 = NextWord();
    name2 = NextWord();

    if( (name1 == NULL) || (name2 == NULL) )
    {
        printf("** Error! Invalid name! \n");
        f_Abort();                                         
    }

    hb32(name1,name2);
}

//void hb32_offset(unsigned char * NameIn, unsigned char * NameOut)
void f_hb32o(void)
{
unsigned char *name1,*name2;

    name1 = NextWord();
    name2 = NextWord();

    if( (name1 == NULL) || (name2 == NULL) )
    {
        printf("** Error! Invalid name! \n");
        f_Abort();                                         
    }

    hb32_offset(name1,name2);
}
/* --------------------------------------------------------------------------
					 㭪樨  类஫ ᨩ
-------------------------------------------------------------------------- */

/*
inc_major
inc_minor
inc_micro
         
set_type(
*/





void f_inc_major(void)  { mk.inc_major();  }
void f_inc_minor(void)  { mk.inc_minor();  }
void f_inc_micro(void)  { mk.inc_micro();  }
void f_inc_build(void)  { mk.inc_build();  }

void f_set_type( void ) { mk.set_type( StackData.pop() ); }

void f_ShowVersion(void)  { mk.ShowVersion();   }

void f_Version0(void)  { StackData.push(mk.Version0()); }
void f_Version1(void)  { StackData.push(mk.Version1()); }
void f_Version2(void)  { StackData.push(mk.Version2()); }
void f_Version3(void)  { StackData.push(mk.Version3()); }
void f_Build(void)      { StackData.push(mk.Build());   }
void f_Time(void)       { StackData.push(mk.Time());    }
void f_Type(void)       { StackData.push(mk.Type());    }
void f_SetVersion0(void)  { mk.SetVersion0(StackData.pop());    }
void f_SetVersion1(void)  { mk.SetVersion1(StackData.pop());    }
void f_SetVersion2(void)  { mk.SetVersion2(StackData.pop());    }
void f_SetVersion3(void)  { mk.SetVersion3(StackData.pop());    }
void f_SetBuild(void)     { mk.SetBuild(   StackData.pop());    }



/* --------------------------------------------------------------------------
							樠
-------------------------------------------------------------------------- */


void _InitBind(void)
{

// ====== UTIL
    AddFunc(&f_TerminateOnError,(unsigned char *)"terminateonerror",T_INST, 0 );
    AddFunc(&f_TestON,          (unsigned char *)"+test",           T_INST, 0 );
    AddFunc(&f_TestOFF,         (unsigned char *)"-test",           T_INST, 0 );
    AddFunc(&f_Stat,            (unsigned char *)"status",          T_INST, 0 );
       
    AddFunc(&f_OpenChannel,     (unsigned char *)"openchannel",     T_COM, 0 );
    AddFunc(&f_OpenCom1,        (unsigned char *)"opencom1",        T_COM, 0 );
    AddFunc(&f_OpenCom2,        (unsigned char *)"opencom2",        T_COM, 0 );
    AddFunc(&f_RTS,             (unsigned char *)"rts",             T_COM, 0 );
    AddFunc(&f_RTS_TOGGLE,      (unsigned char *)"rts_toggle",      T_COM, 0 );

    AddFunc(&f_DTR,             (unsigned char *)"dtr",             T_COM, 0 );
    AddFunc(&f_setbaud,         (unsigned char *)"setbaud",         T_COM, 0 );
    AddFunc(&f_reset_DTR,       (unsigned char *)"reset_dtr",       T_COM, 0 );
    AddFunc(&f_PORT_MODE,       (unsigned char *)"port_mode",       T_COM, 0 );

    AddFunc(&f_evenparity,      (unsigned char *)"evenparity",      T_COM, 0 );
    AddFunc(&f_noparity,        (unsigned char *)"noparity",        T_COM, 0 );  
    AddFunc(&f_oddparity,       (unsigned char *)"oddparity",       T_COM, 0 ); 
    AddFunc(&f_7bit,            (unsigned char *)"7bit",            T_COM, 0 );      
    AddFunc(&f_8bit,            (unsigned char *)"8bit",            T_COM, 0 );      
    AddFunc(&f_1stop,           (unsigned char *)"1stop",           T_COM, 0 );     
    AddFunc(&f_15stop,          (unsigned char *)"15stop",          T_COM, 0 );    
    AddFunc(&f_2stop,           (unsigned char *)"2stop",           T_COM, 0 );     

    AddFunc(&f_DEBUG,           (unsigned char *)"DEBUG",           T_COM, 0 );
    AddFunc(&f_Lfile,           (unsigned char *)"lfile",           T_FORTH, 0 );        

//    AddFunc(&f_Read515,        (unsigned char *)"read515",          T_INST, 0 );
    AddFunc(&f_CloseChannel,    (unsigned char *)"closechannel",    T_COM, 0 );
    AddFunc(&f_Wsio,            (unsigned char *)"wsio",            T_COM, 0 );
    AddFunc(&f_Rsio,            (unsigned char *)"rsio",            T_COM, 0 );
    AddFunc(&f_WsioStr,         (unsigned char *)"wsiostr",         T_COM, 0 );
    AddFunc(&f_WsioStrStack,    (unsigned char *)"wsiostrstack",    T_COM, 0 );


    AddFunc(&f_download,    (unsigned char *)"dl",    T_COM, 0 );

    AddFunc(&f_ctime,           (unsigned char *)".ctime",          T_VERSION, 0 );

    AddFunc(&f_char,            (unsigned char *)"char",              T_INST, 0 );
    AddFunc(&f_char1,           (unsigned char *)"[char]",            T_INST, IMMEDIATE);
    AddFunc(&purge_sio,         (unsigned char *)"purge_sio",         T_INST, 0 );
    AddFunc(&setbreak,          (unsigned char *)"setbreak",          T_INST, 0 );
    AddFunc(&clrbreak,          (unsigned char *)"clrbreak",          T_INST, 0 );

// --------------------------------------------------------------------------
//                               PM3P
// --------------------------------------------------------------------------
    AddFunc(&f_t_ram,           (unsigned char *)"T_RAM",             T_PM3P, 0 );
    AddFunc(&f_t_flash,         (unsigned char *)"T_FLASH",           T_PM3P, 0 );
    AddFunc(&f_t__ram_p,        (unsigned char *)"T_RAM_P",           T_PM3P, 0 );
    AddFunc(&f_t_flash_p,       (unsigned char *)"T_FLASH_P",         T_PM3P, 0 );
    AddFunc(&f_t_flash,         (unsigned char *)"T_FLASH_M3M_386EX", T_PM3P, 0 );
    AddFunc(&f_t_set,           (unsigned char *)"SET_TARGET",        T_PM3P, 0 );

    AddFunc(&f_jmp,             (unsigned char *)"JMP",               T_PM3P, 0 );
    AddFunc(&f_erase_all,       (unsigned char *)"ERASEALL",          T_PM3P, 0 );
    AddFunc(&f_erase_part,      (unsigned char *)"ERASEPART",         T_PM3P, 0 );
    AddFunc(&f_read,            (unsigned char *)"READ",              T_PM3P, 0 );
    AddFunc(&f_write,           (unsigned char *)"WRITE",             T_PM3P, 0 );
    AddFunc(&f_write_ff,        (unsigned char *)"write_ff",          T_PM3P, 0 );


    AddFunc(&f_write_byte,      (unsigned char *)"WRITE_BYTE",        T_PM3P, 0 );
    AddFunc(&f_write_word,      (unsigned char *)"WRITE_WORD",        T_PM3P, 0 );
    AddFunc(&f_write_dword,     (unsigned char *)"WRITE_DWORD",       T_PM3P, 0 );
    AddFunc(&f_write_dword,     (unsigned char *)"WRITE_FLOAT",       T_PM3P, 0 );

    AddFunc(&f_read_byte,       (unsigned char *)"READ_BYTE",        T_PM3P, 0 );
    AddFunc(&f_read_word,       (unsigned char *)"READ_WORD",        T_PM3P, 0 );
    AddFunc(&f_read_dword,      (unsigned char *)"READ_DWORD",       T_PM3P, 0 );
    AddFunc(&f_read_dword,      (unsigned char *)"READ_FLOAT",       T_PM3P, 0 );



    AddFunc(&f_pm3p_test,       (unsigned char *)"PM3P_TEST",         T_PM3P, 0 );


// 㭪樨  HEX -> BIN ८ࠧ

    AddFunc(&f_hb166,           (unsigned char *)"hb166",           T_INST, 0 );
    AddFunc(&f_hb64,            (unsigned char *)"hb64",            T_INST, 0 );
    AddFunc(&f_hb_fragment32,   (unsigned char *)"hb_fragment32",   T_INST, 0 );
    AddFunc(&f_hb32,            (unsigned char *)"hb32",            T_INST, 0 );
    AddFunc(&f_hb32o,           (unsigned char *)"hb32o",           T_INST, 0 );

    AddFunc(&f_Terminal,        (unsigned char *)"term",            T_INST, 0);
// 㭪樨  类஫ ᨩ


    AddFunc(&f_inc_major,    (unsigned char *)"+major",             T_VERSION, 0 );
    AddFunc(&f_inc_minor,    (unsigned char *)"+minor",             T_VERSION, 0 );
    AddFunc(&f_inc_micro,     (unsigned char *)"+micro",            T_VERSION, 0 );
    AddFunc(&f_inc_build,     (unsigned char *)"+build",            T_VERSION, 0 );
    AddFunc(&f_set_type ,    (unsigned char *)"!type_version",      T_VERSION, 0 );
    

    AddFunc(&f_ShowVersion,     (unsigned char *)".version",        T_VERSION, 0 );
    AddFunc(&f_Version0,        (unsigned char *)"@version0",       T_VERSION, 0 );
    AddFunc(&f_Version1,        (unsigned char *)"@version1",       T_VERSION, 0 );
    AddFunc(&f_Version2,        (unsigned char *)"@version2",       T_VERSION, 0 );
    AddFunc(&f_Version3,        (unsigned char *)"@version3",       T_VERSION, 0 );
    AddFunc(&f_Build,           (unsigned char *)"@build",          T_VERSION, 0 );
    AddFunc(&f_Time,            (unsigned char *)"@time",           T_VERSION, 0 );
    AddFunc(&f_Type,            (unsigned char *)"@type",           T_VERSION, 0 );

    AddFunc(&f_SetVersion0,     (unsigned char *)"!version0",       T_VERSION, 0 );
    AddFunc(&f_SetVersion1,     (unsigned char *)"!version1",       T_VERSION, 0 );
    AddFunc(&f_SetVersion2,     (unsigned char *)"!version2",       T_VERSION, 0 );
    AddFunc(&f_SetVersion3,     (unsigned char *)"!version3",       T_VERSION, 0 );
    AddFunc(&f_SetBuild,        (unsigned char *)"!build",          T_VERSION, 0 );

//

}



