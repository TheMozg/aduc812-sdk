#ifndef __MKDATE__H
#define __MKDATE__H


#define V_POS_MAJOR			0
#define V_POS_MINOR			1
#define V_POS_MICRO			2
#define V_POS_NULL			3

#define V_STATUS_NULL	    0
#define V_STATUS_DEBUG 	    1 
#define V_STATUS_ALPHA  	2
#define V_STATUS_BETA     	3
#define V_STATUS_RELEASE  	4

typedef struct {
    unsigned short    Version[4];     // ������ 1.0.0.0 (������� ����� - ������� ����)
    unsigned long     Build;          // �������� ����� ������
    unsigned short    Type;           // 1 - Debug
                            // 2 - Alpha
                            // 3 - Beta
                            // 4 - Relis
    unsigned long  ltime;           // gmtime ANSI    

} VERSION;



class MKDATE {
private:
    VERSION * ver;

    FILE * handle;

    int CheckFile(void);
    void ReadFile(void);
    void WriteFile(void);
    void InitDATA(void);
    void Init(void);
	void GetVersion(void);

	void operation( unsigned short version_status, unsigned short version_pos );


public:


	
    void inc_major(void) { operation( V_STATUS_NULL, V_POS_MAJOR ); } 
    void inc_minor(void) { operation( V_STATUS_NULL, V_POS_MINOR ); } 
	void inc_micro(void) { operation( V_STATUS_NULL, V_POS_MICRO ); } 

	void inc_build(void) { operation( V_STATUS_NULL, V_POS_NULL ); } 

	void set_type( unsigned short ver_type ) { operation( ver_type, V_POS_NULL ); } 

	void ShowVersion(void);

	unsigned short Version0(void) { GetVersion(); return ver->Version[0]; }
	unsigned short Version1(void) { GetVersion(); return ver->Version[1]; }
	unsigned short Version2(void) { GetVersion(); return ver->Version[2]; }
	unsigned short Version3(void) { GetVersion(); return ver->Version[3]; }

	unsigned long Build(void)	{ GetVersion(); return ver->Build; }
	unsigned short  Type(void)	{ GetVersion(); return ver->Type; }
	unsigned long Time(void)	{ GetVersion(); return ver->ltime; }

	void SetVersion0(unsigned short v) { GetVersion(); ver->Version[0]=v; WriteFile(); }
	void SetVersion1(unsigned short v) { GetVersion(); ver->Version[1]=v; WriteFile(); }
	void SetVersion2(unsigned short v) { GetVersion(); ver->Version[2]=v; WriteFile(); }
	void SetVersion3(unsigned short v) { GetVersion(); ver->Version[3]=v; WriteFile(); }

    void SetBuild(unsigned long b)	 { GetVersion(); ver->Build=b;      WriteFile(); }



    MKDATE() {  ver = new VERSION; 	}

    ~MKDATE() { delete ver; }
};


extern MKDATE mk;

#endif //__MKDATE__H
