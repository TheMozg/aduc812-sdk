#ifndef __SYSLOG__H
#define __SYSLOG__H

#define MAX_STR 256

#include <stdio.h>
#include <err.h>
#include <stdarg.h>
#include <string.h>
#include <time.h>


class SYSLOG  
{
public:

    int print( char * format, ... );
    int print_stdout( char * format, ... );
    int print_localtime( void );
    int print_name( char * name );

    void flush( void ) { if( LOG_ON && ( handle != NULL ) ) fflush( handle ); }
    

    SYSLOG(  ) 
    {
        LOG_ON = 0;
    }

    int init( char * filename ) 
    {

        if( LOG_ON ) return ERR;
        
        LOG_ON = 0; 

        handle = fopen(filename, "wb");    

        if( handle == NULL ) 
            return ERR;
        else
        {
            LOG_ON = 1;
            return OK;
        }
    }    

    virtual ~SYSLOG( void ) 
    {

        if( LOG_ON ) 
        {
            if( handle != NULL ) 
                fclose( handle );
        }
    }

protected:

    FILE *  handle;
    int     LOG_ON;
    char    buf[ MAX_STR ];

};

#endif //  __SYSLOG__H

