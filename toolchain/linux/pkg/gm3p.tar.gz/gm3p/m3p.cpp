/****************************************************************************

    m3p.c -   쨭㬥⠫쭮 ⥬ M3P

    (C) m3p.c, 늫祢 ..  2007 .

 ᢮ ணࠬ;  묮 ⥯୮ ࠭ 쥥 /
஢ 쥥  ᮮ⢥⢨  ᓭᠫ쭮 ⢥
業 GNU, 㡫   ;  ᨨ 2,
 ( 襬 롮)    ᨨ.

 ⠯ணࠬ ࠭  ,  ⮮ 㤥 ⯮,
  - ;   ࠧ㬥 壠࠭⨩
      .  
ﯮ祭 ﯮ஡ ᢥ ᬮ ⥓ᠫ ⢥
業 GNU.

 뤮 뫨  쪮 ᠫ쭮 ⢥ 業
GNU   ⮩ ணࠬ; ᫨ , ⭠ ⥯ : Free
Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
02111-1307 USA

----------------------------------------------------------------------------
㐮, -⏥, ࣪䥤 ࠢ᫨⥫쭮 孨  
e-mail: kluchev@d1.ifmo.ru

****************************************************************************/

#include <stdio.h>
#include <string.h>
#include <sio.h>
#include <tabl.h>
#include <textint.h>
#include <forth.h>
#include <ex.h>
#include <version.h>


#include <glib-2.0/glib.h>

//#define VERSION_M3P "1.8.7"

int main(int argc, char *argv[])
{
char str[128];    

        printf("%s-%s-%d%s, ", PROJNAME, VERSION, BUILD, BUILDTYPE );

	//	printf("glib %d.%d.%d\n", GLIB_MAJOR_VERSION, GLIB_MINOR_VERSION, GLIB_MICRO_VERSION );



        try {  _Init(); }
              
        catch ( Ex_Redef )    
        {  
            printf(" ** Error! Redefenition of function! (_Init() )\n");
            return 1; 
        }

        str[ 0 ] = 0;

        if( argc > 1 )
        {
            for( int i = 1; i < argc; i++ )
            {
                strcat( str, argv[ i ] );
                strcat( str, " ");
            }
            Interpret( str );
        }

        textint();


		//OpenChannel( "com1", 9600 );

        return 0;
}

