#ifndef KBHIT_H_
#define KBHIT_H_

#include <termios.h>

class keyboard
{
public:

      keyboard();
    ~keyboard();
    int kbhit();
    int getch();

private:

    struct termios initial_settings, new_settings;
    int peek_character;

};


#endif /*KBHIT_H_*/
