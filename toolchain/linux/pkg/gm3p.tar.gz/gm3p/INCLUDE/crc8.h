#ifndef __CRC8__H
#define __CRC8__H

unsigned char crc8(unsigned char * buf, unsigned char n, unsigned char crc);
unsigned char crc8stream(unsigned char c, unsigned char crc8);
unsigned char crc8stream1( unsigned char x, unsigned char crc );

#endif // __CRC8__H

