
#include <fcntl.h>                         //
#include <sys/types.h>                     // 
#include <sys/stat.h>                      //   C library
#include <unistd.h>

#include <stdlib.h>
#include <stdio.h>

#include <string.h>
#include <time.h>
#include <tabl.h>
#include <textint.h>
#include <stack.h>
#include <forth.h>
#include <word.h>
#include <vocab.h>
#include <dump.h>
#include <sio.h>
#include <ex.h>


#ifndef O_BINARY
#define O_BINARY 0
#endif


//#include <bind.h>



//unsigned char textbuf[80];
//unsigned char PARAM[80];
//static BufForth[256];


static unsigned int ForDoes=0;
char ABORT = 0;
char ECH0=0;
char Buf[128];
FILE * echohandle;
char ECHO_ON=0;

void CheckExit(void);
void _InitBind(void);


static int T_CONTEXT=T_ALL;
/*
#define T_ALL           0       //  
#define T_FORTH         1
#define T_INST          2
#define T_SYS           3
#define T_COM           4
#define T_USER          5

#define T_PM3P    6
#define T_COMMAND   7

*/

void f_all(void)    { T_CONTEXT=T_ALL;      }
void f_forth(void)  { T_CONTEXT=T_FORTH;    }
void f_inst(void)   { T_CONTEXT=T_INST;     }
void f_sys(void)    { T_CONTEXT=T_SYS;      }
void f_com(void)    { T_CONTEXT=T_COM;      }
void f_user(void)   { T_CONTEXT=T_USER;     }
void f_target(void) { T_CONTEXT=T_PM3P;   }
void f_command(void){ T_CONTEXT=T_COMMAND;  }
void f_vercon(void){ T_CONTEXT=T_VERSION;   }


void emit(char c)
{
    if(ECH0) 
    {
        if(ECHO_ON)
        {
            fprintf(echohandle,"%c",c);     
            if( c == 13 ) fflush( echohandle );
        }
        else
        { 
            printf("ECHO file NOT open!\n"); 
            return; 
        }
    }

    printf("%c",c);
    
}

void f_emit(void)
{
    emit( (char)StackData.pop() );
}


void EmitStr(char * Str)
{
    for(int i=0;i < 80; i++) 
    {
        if( Str[i]==0 ) break;
        StackData.push(Str[i]); f_emit();
    }

}

void f_Abort(void)
{


        ABORT = 1;
        printf("ABORT!\n");
        StackData.Abort();
        StackReturn.Abort();
        StackCycle.Abort();
        MODE=MODE_EXECUTE;
        f_all();

        CheckExit();

}

void f_title(void)
{
    printf("M3-FORTH, Linux version\n");
    printf("Russia, St-Peterburg, IFMO, Computer Science\n");
    printf("Kluchev Arkady (kluchev@d1.ifmo.ru)\n");
}

int ModeExecute(char * name)
{
    if(MODE==MODE_EXECUTE)
        {   
        printf("** Error! This word (%s) work in mode compilation ONLY! ",name);
        f_Abort();
        return 1;
        }
     else
         return 0;

}

int ModeCompilation(char * name)
{
    if(MODE==MODE_COMPILATION)
        {   
        printf("** Error! This word (%s) work in mode execute ONLY! ",name);
        f_Abort();
        return 1;
        }
     else
         return 0;

}








void ShowWords( char *name, int Type)
{
int i;
int count=0;
int n=0;

    
    if( (T_CONTEXT==T_ALL) || (T_CONTEXT==Type) )
        {
        printf("\n\n== %s ==\n",name);
        for(i=1;i<Exec.N+1;i++)
                {
                if(Exec.Type[i]==Type) 
                    {
                    if(n==0) printf("\n");
                    if(++n >3) n=0;
                    printf("%16s ",Exec.Name[i]);
                    ++count;
                    }

                }
    
        }
}

void Words(void)
{
    
    ShowWords("VM COMMAND",T_COMMAND);
    ShowWords("FORTH",T_FORTH);
    ShowWords("INST",T_INST);       
    ShowWords("SYS",T_SYS);
    ShowWords("COM",T_COM);
    ShowWords("VERCON",T_VERSION);
    ShowWords("PM3P",T_PM3P);
    ShowWords("USER",T_USER);
    printf("\n\n");
    printf("== Type's of words: ALL COMMAND FORTH INST COM USER PM3P  VERCON ==\n");
}




void Bye(void)
{

    CloseChannel();
    f_echooff();

    exit( (int) ABORT );


}

void Plus(void)
{
        StackData.push(StackData.pop()+StackData.pop());

}

void Minus(void)    // (a,b -> a-b)
{
unsigned int a;
unsigned int b;

    b=StackData.pop();
    a=StackData.pop();

        StackData.push(a-b);

}

void Umn(void)  // (a,b -> a*b)
{
unsigned int a;
unsigned int b;

    b=StackData.pop();
    a=StackData.pop();

        StackData.push(a*b);

}

void Del(void)  // (a,b -> a/b)
{
unsigned int a;
unsigned int b;

    b=StackData.pop();
    a=StackData.pop();

        StackData.push(a/b);

}

void Mod(void)  // (a,b -> a%b)
{
unsigned int a;
unsigned int b;

    b=StackData.pop();
    a=StackData.pop();

        StackData.push(a%b);

}

void And(void)  // (a,b -> a & b)
{
unsigned int a;
unsigned int b;

    b=StackData.pop();
    a=StackData.pop();

        StackData.push(a&b);

}

void Or(void)  // (a,b -> a | b)
{
unsigned int a;
unsigned int b;

    b=StackData.pop();
    a=StackData.pop();

        StackData.push(a|b);

}

void Xor(void)  // (a,b -> a ^ b)
{
unsigned int a;
unsigned int b;

    b=StackData.pop();
    a=StackData.pop();

        StackData.push(a^b);

}


void Not(void)  // (a -> ~a)
{
unsigned int a;


    a=StackData.pop();
    
    StackData.push(~a);

}



void Point(void)
{
int i;
        sprintf(Buf,"%d ",StackData.pop());
        //fflush(stdout);

        
        for(i=0;i<80;i++)
        {
            if(Buf[i]==0) break;
            StackData.push(Buf[i]); f_emit();
        }
}

void DPoint(void)
{
int i;
        sprintf(Buf,"%d",StackData.pop());
        //fflush(stdout);

        
        for(i=0;i<80;i++)
        {
            if(Buf[i]==0) break;
            StackData.push(Buf[i]); f_emit();
        }
}



void HPoint(void)
{
int i;
        sprintf(Buf,"0x%.8X ",StackData.pop());
        //fflush(stdout);

        
        for(i=0;i<80;i++)
        {
            if(Buf[i]==0) break;
            StackData.push(Buf[i]); f_emit();
        }
}

void H2Point(void)
{
int i;
        sprintf(Buf,"%.2X",StackData.pop());
        //fflush(stdout);

        
        for(i=0;i<80;i++)
        {
            if(Buf[i]==0) break;
            StackData.push(Buf[i]); f_emit();
        }
}

void H4Point(void)
{
int i;
        sprintf(Buf,"%.4X",StackData.pop());
        //fflush(stdout);

        
        for(i=0;i<80;i++)
        {
            if(Buf[i]==0) break;
            StackData.push(Buf[i]); f_emit();
        }
}


void H8Point(void)
{
int i;
        sprintf(Buf,"%.8X",StackData.pop());
        //fflush(stdout);

        
        for(i=0;i<80;i++)
        {
            if(Buf[i]==0) break;
            StackData.push(Buf[i]); f_emit();
        }
}


// :

void f_Create(void)
{
    AddNewFunc(Here,NextWord(),T_USER, 0 );
    ForDoes=Here;
}

void f_Does(void)
{
    StackData.push(ForDoes);
}

void BeginArticle(void)
{
        //Create( NextWord() );
        f_Create();
        
        MODE=MODE_COMPILATION;

}

//  

/*
Addr:               BEGIN   push(Here)
    ---
    ---
    ---
    JMP             AGAIN   Store(JMP)
    Addr                    Addr=pop() Store(Addr)
*/


void f_variable(void)
{
    if(ModeCompilation("VARIABLE")) return;
    
        {
        AddNewFunc(Here,NextWord(),T_USER, 0);
        StoreWord(W_CURRENT_ADDR);
        StoreWord(0);
        }

}


void f_constant(void)
{
   if(ModeCompilation("CONSTANT")) return;
    
        {
        AddNewFunc(Here,NextWord(),T_USER, 0);
        StoreWord(W_CURRENT_VALUE);
        StoreWord(StackData.pop());
        }

}

void f_begin(void)
{
    if(ModeExecute("BEGIN")) return;
//  if(MODE == MODE_COMPILATION)
        StackReturn.push(Here);     
        
}

void f_again(void)
{
    if(ModeExecute("AGAIN")) return;
//  if(MODE == MODE_COMPILATION)
//  {
        StoreWord((int)W_JMP);      
        StoreWord(StackReturn.pop());
//  }
}
/*
    JMP_F           IF      Store(JMP_F)
    Addr                    push(Here) Store(0) 
    ---
    ---
    ---
Addr:               THEN    Addr=pop();
    ---                     [Addr]=Here;
*/

void f_if(void)
{
    if(ModeExecute("IN")) return;
//  if(MODE == MODE_COMPILATION)
//  {
        StoreWord((int)W_JMP_F);        
        StackReturn.push(Here);     
        StoreWord(0);
//  }
}

void f_then(void)
{
unsigned int Addr;
unsigned int *iPtr;

    if(ModeExecute("THEN")) return;

//if(MODE == MODE_COMPILATION)
//  {
    Addr=StackReturn.pop();
    iPtr=(unsigned int *)&Vocabulary[Addr];
    *iPtr=Here;
//  }
}

/*
3. IF ELSE THEN

    JMP_F           IF      Store(JMP_F)
    Addr                    push(Here) Store(0) 
    ---
    ---
    ---
    JMP             ELSE    
    Exit                    Store(JMP)  
Addr:                       push(Here) Store(0)
    ---                     swap() Addr=pop(); [Addr]=Here;
    ---
    ---
Exit:                       Addr=pop();
                            [Addr]=Here

*/

void f_else(void)
{
unsigned int Addr;
unsigned int *iPtr;

    if(ModeExecute("ELSE")) return;

    StoreWord((int)W_JMP);      
    StackReturn.push(Here); 
    StoreWord(0);
    StackReturn.swap();
    Addr=StackReturn.pop();
    iPtr=(unsigned int *)&Vocabulary[Addr];
    *iPtr=Here;

}

/*
4. DO LOOP

    : tt N count do i . loop ;
    
    Count=n1            Count   = Data.pop      
    N=n2                N       = Data.pop
Addr:
    Count >= N          Push(Count) Push(N) >=
    JMP_T   
    Exit
    ---
    ---
    ---
    ---
    ---
    Count++
    JMP 
    Addr
Exit:

*/


void f_do(void)
{
    if(ModeExecute("DO")) return;

    StoreWord(W_POP_COUNT);
    StoreWord(W_POP_N);

    StackReturn.push(Here); // Addr
    StoreWord(W_COMPARE);
    StoreWord(W_JMP_T);
    StackReturn.push(Here); // Exit
    StoreWord(0);
}


void f_loop(void)
{
int Addr,Exit;
unsigned int *iPtr;

    if(ModeExecute("LOOP")) return;

    StoreWord(W_COUNT_INC);
    StoreWord(W_JMP);
    StackReturn.swap();
    Addr=StackReturn.pop();
    StoreWord(Addr);

    Exit=StackReturn.pop();
    iPtr=(unsigned int *)&Vocabulary[Exit];
    *iPtr=Here;

}


void f_i(void)
{

    if(ModeExecute("I")) return;

    StoreWord(W_PUSH_COUNT);
}


/*
5. BEGIN WHILE REPEAT


Addr:               BEGIN   push(Here)
    ---
    ---
    ---
    ---
    JMP_F           WHILE   Store(JMP_F)
    Exit                    push(Here) Store(0)                 
    ---                     
    ---
    ---
    JMP             REPEAT  Store(JMP)
    Addr                    swap() Addr=pop() Store(Addr)
Exit:                       Addr=pop(); [Addr]=Here;
*/

void f_while(void)
{
    if(ModeExecute("WHILE")) return;

    StoreWord((int)W_JMP_F);        
    StackReturn.push(Here); 
    StoreWord(0);
}



void f_repeat(void)
{
unsigned int Addr;
unsigned int *iPtr;

    if(ModeExecute("REPEAT")) return;

    StoreWord((int)W_JMP);      
    StackReturn.swap(); 
    Addr=StackReturn.pop();
    StoreWord(Addr);
    Addr=StackReturn.pop();
    iPtr=(unsigned int *)&Vocabulary[Addr];
    *iPtr=Here;

}


/*
6. BEGIN UNTIL


Addr:               BEGIN   push(Here)
    ---
    ---
    ---
    JMP_F               UNTIL   Store(JMP_F)
    Addr                        Addr=pop() Store(Addr)

*/

void f_until(void)
{
    if(ModeExecute("UNTIL")) return;
        StoreWord((int)W_JMP_F);        
        StoreWord(StackReturn.pop());

}

/*
void f_leave(void)
{
    if(ModeExecute("LOOP")) return;

    StoreWord(W_COUNT_INC);
    StoreWord(W_JMP);
    StackReturn.swap();
    Addr=StackReturn.pop();
    StoreWord(Addr);

    Exit=StackReturn.pop();
    iPtr=(unsigned int *)&Vocabulary[Exit];
    *iPtr=Here;

    StoreWord(W_LEAVE); 
}
*/

void BeginImmediate(void)
{
//unsigned short index;
//unsigned char * s;

//        s=NextWord();
//        Create(s);

        AddNewFunc(Here,NextWord(),T_USER,IMMEDIATE);
        
//        if( index=Find(s) ) StoreWord(index);

        MODE=MODE_COMPILATION;

}


// ;

void EndArticle(void)
{

        StoreWord((int)W_EXIT);

        MODE=MODE_EXECUTE;

}





void ModeExecute(void)
{
        MODE=MODE_EXECUTE;
}


void ModeCompilation(void)
{
        MODE=MODE_COMPILATION;
}


void FromR(void)    // R>
{
    StackData.push(StackReturn.pop());
}


void ToR(void)  // >R
{
    StackReturn.push(StackData.pop());
}


void GetR(void) // R@
{
    StackData.push(StackReturn.get());
}

void PutR(void)
{
    StackReturn.put(StackData.pop());
}


void Swap(void) // a,b -> b,a
{

    StackData.swap();

}

void Dup(void)  // a -> a,a
{
    StackData.dup();
    
}

void Drop(void) // a -> a,a
{
    StackData.drop();
    
}


void ShowDataStack(void)
{
    StackData.show();
}

void ShowReturnStack(void)
{
    StackReturn.show();
}


void f_key(void)
{
    StackData.push(getchar());
}

void f_cr(void)
{
    //printf("\n");
    StackData.push(13); f_emit();
    StackData.push(10); f_emit();
}

void Store(void)    // w32,a32 -> 
{
unsigned int * iTmp;

    int Addr = StackData.pop();
    int word = StackData.pop();


    if( Addr >= VS ) { printf("Access denied!\n");  throw Ex_MemHeap(); }


    iTmp=(unsigned int *)&Vocabulary[Addr];
    *iTmp=word;




}


void ReStore(void)  // a32 -> 
{
unsigned int * iTmp;

    int Addr = StackData.pop();
    


        if( Addr >= VS ) { printf("Access denied!\n");  throw Ex_MemHeap(); }
                
        iTmp=(unsigned int *)&Vocabulary[Addr];
        StackData.push(*iTmp);
                



}

void Storebyte(void)    // w32,a32 -> 
{
unsigned int * iTmp;

    int Addr        = StackData.pop();
    unsigned char c = StackData.pop();


    if( Addr >= VS ) { printf("Access denied!\n");  throw Ex_MemHeap(); }


    Vocabulary[Addr] = c;
}

void ReStorebyte(void)  // a32 -> 
{
    int Addr = StackData.pop();
    


        if( Addr >= VS ) { printf("Access denied!\n");  throw Ex_MemHeap(); }
        
        StackData.push( Vocabulary[Addr] );
}


void Rot(void)  // w1,w2,w3 -> w2, w3, w1
{
    StackData.rot();
    

}

void Over(void) // w1,w2 -> w1,w2,w1
{
    StackData.over();
}


void CompileString(void)
{
unsigned char * cPtr;

int n;

    if(ModeExecute("\"")) return;

    if(MODE==MODE_COMPILATION) 
        {
    
        StoreWord(W_LIT_STR);
        cPtr= NextWordD('"');
        if(cPtr == NULL)
                    {
                    printf("** NULL pointer (string)!\n");    
                    return;
                    }
        n=strlen((char*)cPtr);

        StoreWord(n);
        for(int i=0;i < n; i++)
            StoreByte(cPtr[i]);
        }
}

void CompilePrintString(void)
{
unsigned char * cPtr;

int n;

    if(ModeExecute(".\"")) return;

    if(MODE==MODE_COMPILATION) 
        {
    
        StoreWord(W_LIT_STR_PRINT);
        cPtr= NextWordD('"');
        if(cPtr == NULL)
                    {
                    printf("** NULL pointer (string)!\n");    
                    return;
                    }
        n=strlen((char*)cPtr);

        StoreWord(n);
        for(int i=0;i < n; i++)
            StoreByte(cPtr[i]);
        }
}


void TypeString(void)
{
    unsigned char * cPtr;
    unsigned int * iTmp;

    int Addr=StackData.pop();

    if( Addr >= VS ) { printf("Access denied!\n"); throw Ex_MemHeap(); }
                
    iTmp=(unsigned int *)&Vocabulary[Addr];
    int n= *iTmp;

    cPtr=(unsigned char *)&Vocabulary[Addr+4];

    for(int i=0;i < n; i++) 
    {
        //printf("%c",cPtr[i]);
        StackData.push(cPtr[i]); f_emit();
    }
    //fflush(stdout);
}

void f_Allot(void)
{
    Here+=StackData.pop();
}

void f_Constant(void)
{

}
// -------------------------------------------------------------------------
void f_Dump(void)       //  Addr Len Dump
{
unsigned short Adr, Len;


        Len=StackData.pop();
        Adr=StackData.pop();
        Dump(Adr,Len,Vocabulary);

}


void f_Here(void)       // (-> Here) Here
{
        StackData.push(Here);
}


void f_CompileByte(void)   // (W->) C,
{
        StoreByte(StackData.pop());    
}

void f_CompileWord(void)   // (W->) ,
{
        StoreWord(StackData.pop());    
}


void f_b(void)
{
    int a,b;    // a,b -> c
                // a > b

    b=StackData.pop();
    a=StackData.pop();

    if(a>b) 
        StackData.push(-1);
     else
        StackData.push(0);
}

void f_m(void)
{
    int a,b;    // a,b -> c
                // a < b

    b=StackData.pop();
    a=StackData.pop();

    if(a<b) 
        StackData.push(-1);
     else
        StackData.push(0);
}

void f_be(void)
{
    int a,b;    // a,b -> c
                // a > b

    b=StackData.pop();
    a=StackData.pop();

    if(a>=b) 
        StackData.push(-1);
     else
        StackData.push(0);
}

void f_me(void)
{
    int a,b;    // a,b -> c
                // a < b

    b=StackData.pop();
    a=StackData.pop();

    if(a<=b) 
        StackData.push(-1);
     else
        StackData.push(0);
}

void f_e(void)
{
    int a,b;    // a,b -> c
                // a < b

    b=StackData.pop();
    a=StackData.pop();

    if(a==b) 
        StackData.push(-1);
     else
        StackData.push(0);
}

void f_ne(void)
{
    int a,b;    // a,b -> c
                // a < b

    b=StackData.pop();
    a=StackData.pop();

    if(a!=b) 
        StackData.push(-1);
     else
        StackData.push(0);
}

// -------------------------------------------------------------------------


void f_Rem(void)
{
    REM=1;
}

void f_Rem1(void)
{
    if(ModeExecute("(")) return;

    if(MODE==MODE_COMPILATION) NextWordD(')');
        
}




/*
void Compile(void)
{
    GetR();
    ReStore();
    f_CompileWord();
    FromR();
    StackData.push(4);
    Plus();
    ToR();
}
*/

/*
: >MARK    HERE 0 , ;
: >RESOLVE HERE OVER - SWAP ! ;
: <MARK    HERE ;
: <RESOLVE HERE - , ; 

: COMPILE R@ @ , R> 4 + >R ;
: BRANCH R> @ >R ;

:I BEGIN <MARK ;                     

:I AGAIN COMPILE BRANCH  <RESOLVE ; 

*/

void f_exit()
{
    if(ModeExecute("EXIT")) return;
    StoreWord(W_RETURN);
}


void f_GetCFA(void)
{
    int i;
    char * name;
    char found=1;

    name=(char *)NextWord();
    Upper(name);

    for(i=1;i<Exec.N+1;i++)
                {
                if(strcmp(name,(char *)Exec.Name[i])==0)
                    {
                    found=0;
                    if(Exec.CFA[i] != 0)
                        StackData.push(Exec.CFA[i]);
                     else
                        StackData.push(-1);
                    }
                }
    if(found)
        {
        
        printf("word not found...\n"); 
        f_Abort();
        }


}

void ShowAddr(void * iPtr)
{
    char * cPtr;
    char * Voc;
    int A,B;

    Voc = (char *) Vocabulary;
    cPtr = (char *) iPtr;

    A = (int)cPtr;
    B= (int)Voc;

    printf("[%.8X] ",A-B);

}

void f_DisForth(void)
{
    int Begin;

    int i=0;
    int j,n;
     char * cPtr;
    unsigned int * iPtr;
    Begin=StackData.pop();

    if(Begin == -1) 
        {
        printf("This word is low level...\n");
        return;
        }
    iPtr=(unsigned int *)&Vocabulary[Begin];

    while(1)
    {
    ShowAddr(&iPtr[i]);

    switch(iPtr[i])
        {
        case W_LIT:
            i++;
            printf("LIT ");
            printf("%d\n",iPtr[i++]);
            break;
        case W_EXIT:
            printf("EXIT\n");
            return;
        case W_JMP:
            i++;
            printf("JMP ");
            printf("%X\n",iPtr[i++]);
            break;
        case W_JMP_T:
            i++;
            printf("JMP_T ");
            printf("%X\n",iPtr[i++]);
            break;
        case W_JMP_F:
            i++;
            printf("JMP_F ");
            printf("%X\n",iPtr[i++]);
            break;

        case W_LIT_STR:
            i++;
            n=iPtr[i++];
            cPtr= (char *)&iPtr[i];

            printf("LIT STRING: \"");

            for(j=0;j<n;j++) printf("%c",cPtr[j]);
            iPtr=(unsigned int *)&cPtr[j];
            i=0;
            printf("\"\n");
            break;
        case W_LIT_STR_PRINT:
            i++;
            n=iPtr[i++];
            cPtr= (char *)&iPtr[i];

            printf("LIT PRINT STRING: .\"");

            for(j=0;j<n;j++) printf("%c",cPtr[j]);
            iPtr=(unsigned int *)&cPtr[j];
            i=0;
            printf("\"\n");
            break;

        case W_CURRENT_VALUE:
            printf("CURRENT VALUE\n");
            i++;
            break;
        case W_CURRENT_ADDR:
            printf("CURRENT ADDR\n");
            i++;
            break;
            
        case W_PUSH_COUNT:
            printf("PUSH COUNT\n");
            i++;

            break;
        case W_PUSH_N:
            printf("PUSH N\n");
            i++;
            break;
        case W_POP_COUNT:
            printf("POP COUNT\n");
            i++;
            
            break;
        case W_POP_N:
            printf("POP N\n");
            i++;

            break;
        case W_COUNT_INC:
            printf("INC COUNT\n");
            i++;

            break;
        case W_COMPARE:
            printf("COMPARE COUNT\n");
            i++;
            break;

        case W_RETURN:
            printf("EXIT (RETURN)\n");
            i++;
            break;

        default:
            printf("%s\n",Exec.Name[ iPtr[i] ]);
            i++;
            break;
        }

    if(i>50) return;
    }
}

// -------------------------------------------------------------------------




void f_plusecho(void) { ECH0=1; }
void f_minusecho(void) { ECH0=0; }

void f_echoon(void)
{
char * filename;

    filename=(char *)NextWord();
    echohandle=fopen(filename,"wb");    
    if(echohandle==NULL) throw Ex_File();
    ECHO_ON=1;
}

void f_echooff(void)
{
    if(ECHO_ON) fclose(echohandle);
}


void f_shiftr(void)
{
unsigned long x;

    x=StackData.pop();
    x=x>>1;
    StackData.push(x);

}

void f_shiftl(void)
{
unsigned long x;

    x=StackData.pop();
    x=x<<1;
    StackData.push(x);

}


void f_kbhit(void)
{
    //StackData.push(kbhit());
	StackData.push( 0 );

	printf("kbhit not found\n");
	
}


void f_sleep(void)
{
//    Sleep( StackData.pop() );

	StackData.pop();
	printf("sleep not found\n");

}


void flit_to_sd(void)
{
char * flit;
float f;
unsigned long *w;

    flit = (char *)NextWord();

    if( flit == NULL ) return;

    
    f = (float) atof( flit ); 

//    printf("f = %f \n", f);
    
    w = (unsigned long * ) &f;

    StackData.push( *w );
}


void fpoint(void)
{
float f;
unsigned long *w;

    w = (unsigned long * ) &f;
    
    *w = StackData.pop();
   
    printf("%f", f);

    fflush(stdout);
}

/*
int birom(unsigned char * filename, unsigned long addr )
{
int handleIn;
int Len;
int res;

    if(filename==NULL)
    {
        cout << "Error of filename!" << endl;
        return 1;
    }

    handleIn = _open((char *)filename,  _O_RDONLY|O_BINARY );

    ifstream    input ( handleIn ); 
    switch(errno)
        {
         case EACCES: cout << "File " << filename << ": Access denied! " << endl;             return 1;
         case EMFILE: cout << "File " << filename << ": No more handles available!"  << endl; return 1;
         case ENOENT: cout << "File " << filename << ": Path or file not found!"  << endl;    return 1;       
         }    


    input.read(birom_buf,32768);
    Len = input.gcount();

    printf("birom: %s, %d\n", filename,Len);
    
    res = buf_to_birom(addr, Len, birom_buf);

     input.close();
    _close(handleIn);

    return res;
}

*/


void f_open_file( void )
{
char * name;

    name = (char *)NextWord();

    if( name == NULL ) 
    {
        printf("Invalid filename! \n");
        return;
    }

    StackData.push ( open( name,  O_RDONLY|O_BINARY ) );

}

void f_create_file( void )
{
char * name;

    name = (char *)NextWord();

    if( name == NULL ) 
    {
        printf("Invalid filename! \n");
        return;
    }

    StackData.push ( creat( name,  S_IREAD | S_IWRITE ) );

}


void f_close_file( void )
{
    close( StackData.pop() );

}

// handle addr len
void f_read_file( void )
{
int len, addr, handle;

    len    = StackData.pop();
    addr   = StackData.pop();
    handle = StackData.pop();

    StackData.push ( read( handle, &Vocabulary[addr], len ) );
}


void f_write_file( void )
{
int len, addr, handle;

    len    = StackData.pop();
    addr   = StackData.pop();
    handle = StackData.pop();

    StackData.push ( write( handle, &Vocabulary[addr], len ) );
}


// addr, len, byte
void f_fill( void )
{
int len, addr, c, i;

    
    c      = StackData.pop();
    len    = StackData.pop();
    addr   = StackData.pop();
    

    for( i = 0; i < len; i++ )
        Vocabulary[addr + i] = c;    
}

void _Init(void)
{
unsigned long i;


        //STACK.SP = StackSize-1;         // ⠭ 㪠⥫ ⥪
        //SysErr = 0;                   //  䫠 訡



        for(i=0;i<VS;i++) Vocabulary[i]=0xFF;
        Here=2;

    
        AddFunc(&f_title,         (unsigned char *)".title",        T_FORTH, 0 );
        AddFunc(&f_Rem,         (unsigned char *)"//",        T_FORTH, IMMEDIATE);
        AddFunc(&f_Rem,         (unsigned char *)"--",        T_FORTH, IMMEDIATE);
        AddFunc(&f_Rem1,         (unsigned char *)"(",        T_FORTH, IMMEDIATE);
//#if !defined(RELIS) 

        AddFunc(&Bye,            (unsigned char *)"bye",         T_FORTH, 0 );
        AddFunc(&Plus,           (unsigned char *)"+",           T_FORTH, 0 );
        AddFunc(&Minus,          (unsigned char *)"-",        T_FORTH, 0 );
        AddFunc(&Umn,            (unsigned char *)"*",        T_FORTH, 0 );
        AddFunc(&Del,            (unsigned char *)"/",        T_FORTH, 0 );
        AddFunc(&Mod,            (unsigned char *)"%",        T_FORTH, 0 );

        AddFunc(&And,            (unsigned char *)"and",        T_FORTH, 0 );
        AddFunc(&Or,             (unsigned char *)"or",        T_FORTH, 0 );
        AddFunc(&Xor,            (unsigned char *)"xor",        T_FORTH, 0 );
        AddFunc(&Not,            (unsigned char *)"not",        T_FORTH, 0 );

        AddFunc(&Words,          (unsigned char *)"words",       T_FORTH, 0 );
        AddFunc(&Point,          (unsigned char *)".",           T_FORTH, 0 );
        AddFunc(&DPoint,          (unsigned char *)"d.",           T_FORTH, 0 );
        AddFunc(&HPoint,          (unsigned char *)"h.",           T_FORTH, 0 );
        AddFunc(&H2Point,          (unsigned char *)"2h.",           T_FORTH, 0 );
        AddFunc(&H4Point,          (unsigned char *)"4h.",           T_FORTH, 0 );
        AddFunc(&H8Point,          (unsigned char *)"8h.",           T_FORTH, 0 );

        AddFunc(&BeginArticle,   (unsigned char *)":",           T_FORTH, 0 );
        AddFunc(&BeginImmediate, (unsigned char *)":i",          T_FORTH, 0 );
        AddFunc(&EndArticle,     (unsigned char *)";",           T_FORTH, IMMEDIATE);
        AddFunc(&ModeExecute,    (unsigned char *)"[",           T_FORTH, 0 );
        AddFunc(&ModeCompilation,(unsigned char *)"]",           T_FORTH, 0 );
        AddFunc(&f_CompileByte,  (unsigned char *)"c,",          T_FORTH, 0 );
        AddFunc(&f_CompileWord,  (unsigned char *)",",           T_FORTH, 0 );        



        AddFunc(&f_Dump,         (unsigned char *)"dump",        T_FORTH, 0 );
        AddFunc(&f_Here,         (unsigned char *)"here",        T_FORTH, 0 );

        AddFunc(&f_begin,        (unsigned char *)"begin",        T_FORTH, IMMEDIATE);
        AddFunc(&f_again,        (unsigned char *)"again",        T_FORTH, IMMEDIATE);
        AddFunc(&f_do,           (unsigned char *)"do",        T_FORTH, IMMEDIATE);
        AddFunc(&f_loop,         (unsigned char *)"loop",        T_FORTH, IMMEDIATE);
        AddFunc(&f_exit,         (unsigned char *)"exit",        T_FORTH, IMMEDIATE);
        AddFunc(&f_while,        (unsigned char *)"while",        T_FORTH, IMMEDIATE);
        AddFunc(&f_repeat,        (unsigned char *)"repeat",        T_FORTH, IMMEDIATE);
        AddFunc(&f_until,        (unsigned char *)"until",        T_FORTH, IMMEDIATE);

        AddFunc(&f_i,            (unsigned char *)"i",        T_FORTH, IMMEDIATE);
        AddFunc(&f_i,            (unsigned char *)"j",        T_FORTH, IMMEDIATE);
        AddFunc(&f_i,            (unsigned char *)"k",        T_FORTH, IMMEDIATE);

        AddFunc(&f_if,           (unsigned char *)"if",        T_FORTH, IMMEDIATE);
        AddFunc(&f_then,         (unsigned char *)"then",        T_FORTH, IMMEDIATE);
        AddFunc(&f_else,           (unsigned char *)"else",        T_FORTH, IMMEDIATE);

        AddFunc(&f_b,           (unsigned char *)">",        T_FORTH, 0 );
        AddFunc(&f_m,           (unsigned char *)"<",        T_FORTH, 0 );
        AddFunc(&f_be,          (unsigned char *)">=",        T_FORTH, 0 );
        AddFunc(&f_me,          (unsigned char *)"<=",        T_FORTH, 0 );
        AddFunc(&f_e,           (unsigned char *)"==",        T_FORTH, 0 );
        AddFunc(&f_ne,          (unsigned char *)"<>",        T_FORTH, 0 );

        AddFunc(&f_Abort,        (unsigned char *)"abort",        T_FORTH, 0 );
        AddFunc(&f_Allot,        (unsigned char *)"allot",        T_FORTH, 0 );

        AddFunc(&FromR,          (unsigned char *)"R>",        T_FORTH, 0 );
        AddFunc(&ToR,            (unsigned char *)">R",        T_FORTH, 0 );
        AddFunc(&GetR,            (unsigned char *)"R@",        T_FORTH, 0 );
        AddFunc(&PutR,            (unsigned char *)"R!",        T_FORTH, 0 );
        AddFunc(&Swap,           (unsigned char *)"swap",        T_FORTH, 0 );
        AddFunc(&Dup,            (unsigned char *)"dup",        T_FORTH, 0 );
        AddFunc(&Drop,            (unsigned char *)"drop",        T_FORTH, 0 );
        AddFunc(&ShowDataStack,  (unsigned char *)"s.",        T_FORTH, 0 );
        AddFunc(&ShowReturnStack, (unsigned char *)"r.",        T_FORTH, 0 );
        AddFunc(&f_key,         (unsigned char *)"key",        T_FORTH, 0 );
        AddFunc(&f_cr,          (unsigned char *)"cr",        T_FORTH, 0 );

        AddFunc(&Store,         (unsigned char *)"!",        T_FORTH, 0 );
        AddFunc(&ReStore,       (unsigned char *)"@",        T_FORTH, 0 );
        AddFunc(&Storebyte,     (unsigned char *)"c!",        T_FORTH, 0 );
        AddFunc(&ReStorebyte,   (unsigned char *)"c@",        T_FORTH, 0 );
        AddFunc(&Rot,           (unsigned char *)"rot",        T_FORTH, 0 );
        AddFunc(&Over,          (unsigned char *)"over",        T_FORTH, 0 );
        AddFunc(&CompileString, (unsigned char *)"\"",        T_FORTH, IMMEDIATE);
        AddFunc(&CompilePrintString,    (unsigned char *)".\"",        T_FORTH, IMMEDIATE);
        AddFunc(&TypeString,    (unsigned char *)"type",        T_FORTH, 0 );
//      AddFunc(&Compile,       (unsigned char *)"compile",        T_FORTH, 0 );
        AddFunc(&f_DisForth,    (unsigned char *)"disforth",    T_FORTH, 0 );
//        AddFunc(&f_Create,        (unsigned char *)"create",    T_FORTH, 0 );
//        AddFunc(&f_Does,      (unsigned char *)"does",    T_FORTH, 0 );
        AddFunc(&f_variable,        (unsigned char *)"variable",    T_FORTH, 0 );
        AddFunc(&f_constant,        (unsigned char *)"constant",    T_FORTH, 0 );

        AddFunc(&f_all,         (unsigned char *)"all",    T_FORTH, 0 );
        AddFunc(&f_forth,       (unsigned char *)"forth",    T_FORTH, 0 );
        AddFunc(&f_inst,        (unsigned char *)"inst",    T_FORTH, 0 );
        AddFunc(&f_sys,         (unsigned char *)"sys",    T_FORTH, 0 );
        AddFunc(&f_com,         (unsigned char *)"com",    T_FORTH, 0 );
        AddFunc(&f_user,        (unsigned char *)"user",    T_FORTH, 0 );
        AddFunc(&f_target,      (unsigned char *)"target",    T_FORTH, 0 );
        AddFunc(&f_command,     (unsigned char *)"command",    T_FORTH, 0 );
        AddFunc(&f_vercon,      (unsigned char *)"vercon",    T_FORTH, 0 );

        AddFunc(&f_GetCFA,      (unsigned char *)"'",    T_FORTH, 0 );
//#endif

        AddFunc(&f_emit,        (unsigned char *)"emit",    T_FORTH, 0 );
        AddFunc(f_plusecho,     (unsigned char *)"+echo",    T_FORTH, 0 );
        AddFunc(f_minusecho,    (unsigned char *)"-echo",    T_FORTH, 0 );
        AddFunc(f_echoon,       (unsigned char *)"echo",    T_FORTH, 0 );
        AddFunc(f_echooff,      (unsigned char *)"\\echo",    T_FORTH, 0 );
        AddFunc(f_shiftr,       (unsigned char *)">>",    T_FORTH, 0 );
        AddFunc(f_shiftl,       (unsigned char *)"<<",    T_FORTH, 0 );
        AddFunc(f_kbhit,        (unsigned char *)"?terminal",    T_FORTH, 0 );
        AddFunc(f_sleep,        (unsigned char *)"sleep",    T_FORTH, 0 );

        AddFunc(flit_to_sd,     (unsigned char *)"#f",    T_FORTH, 0 );
        AddFunc(fpoint,         (unsigned char *)"f.",    T_FORTH, 0 );    


        AddFunc(f_open_file,    (unsigned char *)"open_file",   T_FORTH, 0 );       
        AddFunc(f_create_file,  (unsigned char *)"create_file", T_FORTH, 0 );       
        AddFunc(f_close_file,   (unsigned char *)"close_file",  T_FORTH, 0 );       
        AddFunc(f_read_file,    (unsigned char *)"read_file",   T_FORTH, 0 );
        AddFunc(f_write_file,   (unsigned char *)"write_file",  T_FORTH, 0 );
        AddFunc(f_fill,         (unsigned char *)"fill",        T_FORTH, 0 );    

    _InitBind();


}

