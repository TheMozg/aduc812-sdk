#ifndef __HB166_H
#define __HB166_H

extern void hb16(unsigned char *NameIn, unsigned char *NameOut);
extern void hb32(unsigned char *NameIn, unsigned char *NameOut);
extern void hb64(unsigned short addr_b, unsigned short fragment_len, unsigned char * NameIn, unsigned char * NameOut);
void hb32_offset(unsigned char * NameIn, unsigned char * NameOut);
void hb_fragment32(unsigned long addr_b, unsigned long fragment_len, unsigned char * NameIn, unsigned char * NameOut);


#endif // __HB166_H


