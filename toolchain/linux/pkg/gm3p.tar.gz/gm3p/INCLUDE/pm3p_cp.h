#ifndef __PM3P_CP__H
#define __PM3P_CP__H

#include <sio.h>
#include <err.h>
#include <syslog.h>

class PM3P_CP  {

protected:

unsigned char out_buf[ 256 ];
unsigned char in_buf[  256 ];
unsigned char len;
unsigned char crc;

SYSLOG  log;

    void crc_wsio( unsigned char c, unsigned char * crc ); 
    void cp_wsio( unsigned char c ); 
    unsigned char crc_rsio(void); 
    unsigned char cp_rsio(void); 


public:

    int send( unsigned char * buf, unsigned char n, unsigned char command );
    int receive( unsigned char * buf, unsigned char * n, unsigned char *command );


    PM3P_CP( ) 
    {
        log.init( "pm3p_cp.txt" ); 
    }    

    ~PM3P_CP( ) 
    {

    }
    
};

#endif //__PM3P_CP__H
