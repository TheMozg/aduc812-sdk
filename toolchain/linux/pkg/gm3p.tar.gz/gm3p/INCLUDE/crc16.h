#ifndef __CRC16_H
#define __CRC16_H

unsigned short crc16(unsigned char *data, unsigned short count, unsigned short crc);
unsigned short crc16stream(unsigned char data, unsigned short crc);


#endif // __CRC16_H
