#ifndef TERMINAL_H_
#define TERMINAL_H_




void Terminal(int Mode); // 0 Bin, 1 Hex, 2 Dump
//static void multiterm(char c, int stop, int tstamp);
#endif /*TERMINAL_H_*/
