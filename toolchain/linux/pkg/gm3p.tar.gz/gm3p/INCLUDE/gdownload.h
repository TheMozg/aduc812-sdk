#ifndef GDOWNLOAD_H_
#define GDOWNLOAD_H_



int gdownload (char* fname);

int readBlockFromFile (FILE *FptrIn,unsigned long *addr,
                       int *len, unsigned char *data);
int GetVersion(void);
int SendPacket(unsigned char *message,int length);
int waitForRev2Signature(char *sig,int *major,int *minor);
int SendLoaderPacket(int len, char *data);

int WaitForAck(int timeout);
int download(char *program);
int readRecordFromFile(FILE *FptrIn,unsigned char *Record);

int checkParams(char *portdev, unsigned int *baud, char *filename,
                       int *dontEraseData, int *autoRun);
                       
                       
#endif /*GDOWNLOAD_H_*/
