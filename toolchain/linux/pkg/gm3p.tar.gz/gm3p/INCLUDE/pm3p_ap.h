#ifndef __PM3P_AP__H
#define __PM3P_AP__H

#include <sio.h>
#include <err.h>
#include <pm3p_cp.h>

#define AP_NOT_CONNECT         0x40    // ��� �裡 (������ ���௠��)
#define CP_REPEAT              0x81


#define CH_COM_DATAPACK 0x1
#define CH_COM_REPEAT   0x81


class PM3P_AP  {

protected:

unsigned char out_buf[ 256 ];
unsigned char in_buf[  256 ];
unsigned char wait_answer_disable;

SYSLOG  log;
PM3P_CP pm3p_cp;

public:

    int send(   unsigned char * err, 
                unsigned char * target, 
                unsigned char * command, 
                unsigned char * buf, 
                unsigned char * n );
    void disable_wait_answer( void ) { wait_answer_disable = 1; }


    PM3P_AP( ) 
    {
        log.init( "pm3p_ap.txt" );
        wait_answer_disable = 0;
    }    

    ~PM3P_AP( ) 
    {

    }
    
};

#endif //__PM3P_AP__H

