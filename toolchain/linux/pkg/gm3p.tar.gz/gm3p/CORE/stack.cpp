#include <stdio.h>
#include <stack.h>
#include <ex.h>

STACK StackData;
STACK StackReturn;
STACK_PARSING StackCycle;

void STACK::push(int val)
{
    if(SP==0) { printf("Stack overflow!\n"); throw Ex_STACK(); }
    Data[SP] = val;
    SP--;
}

int STACK::pop(void)
{
int val;

    if(SP==(StackSize-1)) { printf("Stack empty!\n");  throw Ex_STACK(); }   
    SP++;
    val = Data[SP];
    return val;
}

int STACK::get(void)
{
int val;

    if(SP==(StackSize-1)) { printf("Stack empty!\n"); throw Ex_STACK(); }   
    val = Data[SP+1];
    return val;
}

void STACK::put(int val)
{
    if(SP==0) { printf("Stack overflow!\n"); throw Ex_STACK(); }
    Data[SP+1] = val;
    
}

void STACK::drop(void)
{

    if(SP==(StackSize-1)) { printf("Stack empty!\n");  throw Ex_STACK(); }   
    SP++;
}

void STACK::dup(void) {
                a = pop();

                push(a);
                push(a);
    }

void STACK::swap(void) {    
                    b = pop();
                    a = pop();

                    push(b);
                    push(a); }
void STACK::rot(void) {

    int a3 = pop();
    int a2 = pop();
    int a1 = pop();

    push(a2);
    push(a3);
    push(a1);
}

void STACK::over(void)  // a1,a2 -> a1,a2,a1
{
    int a2 = pop();
    int a1 = pop();

    push(a1);
    push(a2);
    push(a1);


}

void STACK::show(void)
{
    int count=0;

    int i;


    if(SP==(StackSize-1))   // ���� ����
        {
        printf(" Stack empty!\n");
        return;
        }

    printf("\n Stack buffer, top in left: "); fflush(stdout);

    i=SP+1;

    printf("\n");   
    while(i!=StackSize) {
                        printf(" 0x%.8X",Data[i++]);
                        if(count++ > 5) count=0, printf("\n");
                        }   
    fflush(stdout);
}


// -----------------------------------------------------------------------------------------------
void STACK_PARSING::check_parse(void)
{
if(SP==(StackSize-1)) { printf("Parsing error!\n");  throw Ex_PARSING(); }   
}
