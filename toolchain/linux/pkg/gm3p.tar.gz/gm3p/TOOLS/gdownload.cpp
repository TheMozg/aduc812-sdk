#include <stdio.h> // чтение hex-файлов
#include <string.h> // копирование строк
#include <time.h> // задержки
#include <ctype.h> // toupper

#include <sio.h> // uart
 

#include <gdownload.h>

const int retrys = 5;

/* function prototypes */


/*			MAIN			*/
int gdownload(char *fname)
{
	char portdev[15]="/dev/ttyS0";               
  //	unsigned int baudrate=9600;          
  	long cmdStartAddress=-1;
  	long startAddress=0x0000;    
  	char filename[256]="";       
  //	double crystal=11.059200;    
  	int rMajor, rMinor;          
  	int dontEraseData = 0;       
  	int autoRun=0;              
	int result;
	
	strcpy(filename,fname);
	
//	DecodeCmdL(argc,argv,portdev,&baudrate,filename,&dontEraseData,&autoRun,&cmdStartAddress);
	
	
	time_t ctm;
	
	time(&ctm);
	 //localtime( &ctm );
	printf("%s\n",asctime(localtime( &ctm ))  );
	
	
	
	printf("filename=%s\r\n",filename);
	fflush(stdout);
	
	//if(checkParams(portdev,&baudrate,filename,&dontEraseData,&autoRun))
   // printf ("Wrong Params \r\n");
	

	
	//if(OpenChannel(portdev,baudrate)) return 0;
	
	if(GetVersion()) return 1;
	
	SendLoaderPacket(1,"A");
    if(WaitForAck(1000)) printf ("Starting..");
	result= download(filename);
	switch (result)
		{
		case 0: printf ("\n OK!\n");
		 		break;
		case 1: printf ("\n not reset \n");
				break;
		case 2: 
				break;
		case 3: printf ("\n failed \n");
				break;
		case 4: printf ("\n not found \n");
				break;
		}
	CloseChannel();
	
	printf("\n");
	
	return 0;
}






int GetVersion(void)
{
		clock_t stime; 
		int ik=25;
		unsigned char data[4];
		char crc;
		
		char ss[100];
		int minor=0,major=0;
		
		data[0]=0x21;
		data[1]=0x5A;
		data[2]=0x00;
		data[3]=0xA6;
		
	//	Wsio(data[0]);
	//	Wsio(data[1]);
	//	Wsio(data[2]);
	//	Wsio(data[3]);
	
		SendPacket(data,4);
		
		if(waitForRev2Signature(ss,&major,&minor))
		{
		printf ("Nice!");
		printf ("=%s - %d - %d=",ss,major,minor);
		return 0;
		}
	   else printf ("Cannot reset device\n");
	
	/*
		while ( ik)
	{
		if ( RsioStat() )
		{
			crc = Rsio();
			printf("%c",crc);
			fflush(stdout);
			ik--;
		}
	}
		printf("!%d!\n",crc);
	*/

		return 1;
		}
		
		
/*sends a data packet to the target*/
int SendPacket(unsigned char *message,int length)
{
 

  for (int i=0;i<length;i++)
  		Wsio(message[i]);
  return 1;
}


int waitForRev2Signature(char *sig,int *major,int *minor)
{
  int i=0;
  int state=0;
  time_t startt,endt;        //clock variable for determining timeouts
  unsigned char ch;
  unsigned char checksum=0;
  unsigned char data[30];
  strcpy(sig,"none");
 
   time (&startt);      //get start clock value
  while(1)                  //keep trying....
  {
    if(RsioStat())         //see if any data from the target
    {
      ch=Rsio();          //get the data
      printf("%c",ch);
      data[state]=ch;
      checksum+=ch;
      switch(state) //see what we are doing....
      {             //watch for fallthroughs in this switch statement
      case 0:       //waiting for start character ("A")
        if(ch=='A')
          state++;
        else
          checksum=0;
        break;
      case 1:
        if(ch=='D')         //waiting for second character ("D")
          state++;
        else
          state=0;
        break;
      case 2:               //waiting for third character ("I")
        if(ch=='I')
          state++;
        else
          state=0;
        break;
      case 3:               //waiting for device partname
        /*Since we scrap the "ADI" part code header,
          replace it with "ADuC"*/
        strcpy(sig,"ADuC");
        i=4;                //position of next character
      case 4:
      case 5:
      case 6:
      case 7:
      case 8:
      case 9:
        /*if the character in the device partname is a printable
          character, other than capital "X" or space " ", then
          add it to the signature string*/
        if((isprint(ch)) && (ch!='X') && (ch!=' '))
          sig[i++]=ch;
        sig[i]='\0';
        state++;
        break;
      case 10:
        if(ch=='V')
          state++;
        else
          state=0;
	break;
      case 11:
        if(isdigit(ch)){
          *major=ch-'0';
          state++;
        }
        else
          state=0;
        break;
      case 12:
        if(isdigit(ch)){
          *minor=(ch-'0')*10;
          state++;
        }
        else
          state=0;
        break;
      case 13:
        if(isdigit(ch)){
          *minor+=(ch-'0');
          state++;
        }
        else
          state=0;
        break;
      case 14:
        if(ch=='\r')
          state++;
        else
          state=0;
        break;
      case 15:
        if(ch=='\n')
          state++;
        else
          state=0;
        break;
      case 16:     //waiting for hardware id hi byte: ignore
      case 17:     //waiting for hardware id lo byte: ignore
      case 18:     //waiting for firmware id hi byte: ignore
      case 19:     //waiting for firmware id lo byte: ignore
      case 20:     //waiting for age hi byte:         ignore
      case 21:     //waiting for age lo byte:         ignore
      case 22:     //waiting for spare byte:          ignore
      case 23:     //waiting for spare byte:          ignore
        state++;
        break;
      case 24:     //waiting for checksum
        return (checksum==0);
      }
    }
    else
    {
     time (&endt); 
    if(difftime(endt,startt)>1.0)     //see if timeout has elapsed
      return 0;
    }                    //timeout failure
  }
}



/*sends a correctly formated loader command packet to the target*/
int SendLoaderPacket(int len, char *data)
{
  unsigned char packet[128];  //the loader packet
  unsigned char xsum;         //temp var to calculate the checksum
  int i;
  /*set up the 070E header*/
  packet[0]=0x07;
  packet[1]=0x0E;
  /*set up the number of data bytes in the loader packet*/
  packet[2]=len;
  /*copy the data into the packet*/
  for(i=0;i<len;i++)
    packet[3+i]=data[i];
  /*now calculate the checksum of the packet*/
  /*ignore the header, but include the length byte*/
  xsum=len;
  for(i=0;i<len;i++)
    xsum+=packet[i+3];
  packet[len+3]=0-xsum;
  /*send the packet to the target device*/
  return SendPacket(packet,len+4);
}

int WaitForAck(int timeout)
{
  unsigned char ch;
  int i;
  clock_t starttime;  //clock variable for determining the timeouts
  starttime=clock();  //get start clock value
  while(1)            //keep trying....
    if(RsioStat())   //see if any data from the target
    {
      ch=Rsio();    //get the data
      if(ch==0x06)    //see if it is an ACK
        return 1;     /*success*/
    }
//    else printf("%d\n",++i);   //see if timeout has elapsed
        return 0;                      /*failed (due to timeout)*/
}

int download(char *program)
{
  FILE *pFile;
  unsigned char progData[128];   //block of data to download
  unsigned long progAddr;        //address to download to
  int blockLen;                  //number of bytes in the block
  int result=0;                  /*success*/
  int mxlen;
  /*try and open the file*/
  pFile=fopen(program,"r");
  /*check if it opened ok*/
  if(pFile!=NULL)
  {
  	
 
  	
    while(1)                     //keep going until all downloaded
    {
      /*read a block of data from the file, along with its destination addr*/
      if(readBlockFromFile(pFile,&progAddr,&blockLen,progData))
      {
        /*see if we got data ok*/
        if(blockLen>0)
        {
        
	  char packet[128];
	  int i;
	  result=3;              //assume the worst...
	  /*build up the program packet*/
	  packet[0]='W';                 //write code memory command
          packet[1]=(progAddr>>16)%256;  //set up the 24bit address
          packet[2]=(progAddr>>8) %256;
          packet[3]= progAddr     %256;
          /*copy the program bytes into the packet*/
          for(i=0;i<blockLen;i++)
            packet[i+4]=progData[i];
          /*send the command as a 'loader' packet*/
          if(SendLoaderPacket(blockLen+4,packet))
          {
            /*check to see if the target ack's the command*/
            if(WaitForAck(100))
            {
              /*print a 'progress dot'*/
              printf(".");
              fflush(stdout);
              result=0;
            }
            else
              break;  //break out of the loop
          }
          else
            break;    //break out of the loop
        }
      }
      else
        break;        //break out of the loop
    }
    /*close the intel hex file*/
    fclose(pFile);
  }
  else
    result=4;
  return result;
}



int readBlockFromFile (FILE *FptrIn,unsigned long *addr,
                       int *len, unsigned char *data)
{
  char Record[128];
  int bytecount;
  unsigned char xsum=0;
  int rectype;
  int packetxsum;
  int i;
  if(readRecordFromFile(FptrIn,(unsigned char*)Record))
  {
    /*get the number of data bytes in the record*/
    if(sscanf(Record+1,"%2X",&bytecount)!=1) return 0;
    xsum+=bytecount;
    /*get the block start address*/
    if(sscanf(Record+3,"%4lX",addr)!=1) return 0;
    xsum+=(*addr)/256;
    xsum+=(*addr)%256;
    /*get the record type*/
    if(sscanf(Record+7,"%2X",&rectype)!=1) return 0;
    xsum+=rectype;
    /*get the data from the record*/
    for(i=0;i<bytecount;i++)
    {
      if(sscanf(Record+9+i*2,"%2X",data+i)!=1) return 0;
      xsum+=data[i];
    }
    /*get the checksum from the record*/
    if(sscanf(Record+9+bytecount*2,"%2X",&packetxsum)!=1) return 0;
    xsum+=packetxsum;
    /*validate the checksum*/
    if(xsum!=0)
      return 0;
    /*make sure it's a type of records that we can handle*/
    if(rectype==0)         //only return type 0 records
      *len=bytecount;
    else if(rectype==1)    //ignore type 1 records
      *len=0;
    else
      return 0;            //fail on any other type of records
    return 1;
  }
  return 0;
}


int readRecordFromFile(FILE *FptrIn,unsigned char *Record)
{
// read a record from file
  int Index=0;
  unsigned char InChar;
  InChar=fgetc(FptrIn);
  while((InChar!='\n') && ((char)InChar!=EOF))
  {
    Record[Index++]=InChar;
    InChar=fgetc(FptrIn);
  }
  Record[Index] = '\0';
  if (Index==0) return 0;        /*nothing read*/
  if (Record[0]!=':') return 0;  /*not a intel hex record*/
  return 1;
}



int checkParams(char *portdev, unsigned int *baud, char *filename,
                       int *dontEraseData, int *autoRun)
{
      if (*baud!=9600) return 1;
      if ( !((*dontEraseData == 1 )||(*dontEraseData == 0)) ) return 1;
      if ( !((*autoRun == 1 )||(*autoRun == 0)) ) return 1;             
                       return 0;
                       }

