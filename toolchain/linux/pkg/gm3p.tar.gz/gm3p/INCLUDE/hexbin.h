#ifndef __HEXBIN__H
#define __HEXBIN__H

unsigned char CharHexBin(unsigned char * Hex);
unsigned short IntHexBin(unsigned char * Hex);

int CheckKS(unsigned char * HexBlock);
unsigned char GetHexLen(unsigned char * HexBlock);
unsigned short GetHexAdr(unsigned char * HexBlock);
unsigned char GetHexCom(unsigned char * HexBlock);
unsigned short GetHexSeg(unsigned char * HexBlock);
unsigned char GetHexData(unsigned char * HexBlock, unsigned char index);

unsigned char Binary(unsigned char ByteH, unsigned char ByteL);
void Hexadecimal(unsigned char BinNum, unsigned char *HexNum);
int CheckHexChar(unsigned char Byte);

void HexLIB(void);

#endif // __HEXBIN__H
