#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>




unsigned char OutBuf[0x400];
unsigned long getbin16(void);
unsigned long  getbin8(void);
unsigned long  getbin4(void);
static void Convert(unsigned int MinA);
void Convert_fragment( unsigned short addr_b, unsigned short fragment_len );
static void Convert_fragment32(unsigned long addr_b, unsigned long fragment_len);

static unsigned int MinAddr(void);

FILE *HandleIN;
FILE *HandleOUT;
FILE *HandleREP;

static void _hb(unsigned long addr_b, unsigned long fragment_len, unsigned char * NameIn, unsigned char * NameOut, int mode);


#define HB_MODE_FULL        0
#define HB_MODE_OFFSET      1
#define HB_MODE_FRAGMENT    2

// Преобразование HEX->BIN (32 разрядный HEX)
// addr_b       -     начальный адрес HEX
// fragment_len -     Длина кода
// NameIn       -     ASCIIZ имя HEX файла   
// NameOut      -     ASCIIZ имя BIN файла   

void hb_fragment32(unsigned long addr_b, unsigned long fragment_len, unsigned char * NameIn, unsigned char * NameOut)
{
    _hb( addr_b, fragment_len, NameIn, NameOut, HB_MODE_FRAGMENT );
}


static void _hb(unsigned long addr_b, unsigned long fragment_len, unsigned char * NameIn, unsigned char * NameOut, int mode)
{

    printf("\n");
    printf("32-разрядный Hex->Bin конвертер\n");
    printf("Адрес начала   : 0x%.8X\n", addr_b ); 
    printf("Длина фрагмента: %ld\n",    fragment_len ); 
    printf("Файл HEX       : %s\n",     NameIn);
    printf("Файл BIN       : %s\n",     NameOut);

    HandleIN  = fopen( (char*) NameIn, "rb" );  if( HandleIN  == NULL ) goto ErrorFileIN;
    HandleOUT = fopen( (char*) NameOut,"wb" );  if( HandleOUT == NULL ) goto ErrorFileOUT;

    switch( mode )
    {
    case HB_MODE_FRAGMENT:  printf("Режим %d: преобразование фрагмента HEX фала\n", mode);
                            Convert_fragment32(addr_b, fragment_len); 
                            break;

    default:                printf("\n\nОшибка! Указанный режим работы (%d) не поддерживается\n", mode); 
                            break;                            
    }

    fclose(HandleIN);
    fclose(HandleOUT);


        return;
ErrorFileIN:
        printf(" [_hb] Не открыть файл входной файл!\n");
    return;

ErrorFileOUT:
        printf(" [_hb] Не открыть выходной файл!\n");
    return;
}



void hb16(unsigned char * NameIn, unsigned char * NameOut)
{
    printf("\nHex->Bin конвертер, версия для ТОЛЬКО для одного сегмента 64К!");
    printf("\nФайл HEX       : %s",NameIn);
    printf("\nФайл BIN       : %s",NameOut);

        HandleIN=fopen((char*)NameIn,"rb");    if(HandleIN==NULL) goto ErrorFileIN;
        HandleOUT=fopen((char*)NameOut,"wb");  if(HandleOUT==NULL) goto ErrorFileOUT;
    Convert(MinAddr());
    fclose(HandleIN);
    fclose(HandleOUT);


        return;
ErrorFileIN:
        printf(" [hb16] Не открыть файл входной файл!\n");
    return;

ErrorFileOUT:
        printf(" [hb16] Не открыть выходной файл!\n");
    return;


}

void hb64(unsigned short addr_b, unsigned short fragment_len, unsigned char * NameIn, unsigned char * NameOut)
{

    printf("\n");
    printf("Hex->Bin конвертер hb64, версия для ТОЛЬКО для одного сегмента 64К!\n");
    printf("Адрес начала   : 0x%.4X\n", addr_b ); 
    printf("Длина фрагмента: %ld\n", fragment_len ); 
    printf("Файл HEX       : %s\n",NameIn);
    printf("Файл BIN       : %s\n",NameOut);

    HandleIN  = fopen( (char*) NameIn, "rb" );  if( HandleIN  == NULL ) goto ErrorFileIN;
    HandleOUT = fopen( (char*) NameOut,"wb" );  if( HandleOUT == NULL ) goto ErrorFileOUT;

    Convert_fragment(addr_b, fragment_len);

    fclose(HandleIN);
    fclose(HandleOUT);


        return;
ErrorFileIN:
        printf(" [hb64] Не открыть файл входной файл!\n");
    return;

ErrorFileOUT:
        printf(" [hb64] Не открыть выходной файл!\n");
    return;


}

unsigned int MinAddr(void)
{
unsigned int Len;
unsigned int Command;
unsigned int  AdrMin=0xFFFF;
unsigned int  AdrCurrent;




    while(1)
        {
        while(fgetc(HandleIN) != ':');
        Len=getbin8();
        AdrCurrent=(unsigned int)getbin16();



        Command=getbin8();
        if(Command==1)
            break;
        if(Command==0)
            {
            if(AdrCurrent<AdrMin) AdrMin=AdrCurrent;
            }
        }

    fseek(HandleIN,0L,SEEK_SET);

    return AdrMin;



}


unsigned long min_addr32(void)
{
unsigned long addr_min = 0xFFFFFFFF; // Минимальная величина 32-разрядного адреса 
unsigned long addr_h   = 0x00000000; // Старшая часть адреса
unsigned long addr_l;                // Младшая часть адреса

    while( 1 )
    {
        while(fgetc(HandleIN) != ':');

        getbin8(); // Len

        addr_l = (unsigned int)getbin16();

        switch( getbin8() ) // command
        {
            case 1: 
                    fseek( HandleIN, 0L, SEEK_SET );
                    return addr_min;
            case 0:
                    if( (addr_h + addr_l ) < addr_min ) addr_min = addr_h + addr_l;
                    break;

            case 2:
                    addr_h = getbin16();
                    addr_h <<= 4;
                    break;
            case 4:
                    addr_h = getbin16();
                    addr_h <<= 16;
                    break;
        }
    }
}


void convert_32_offset( unsigned long offset )
{
int i;
unsigned int Len;
unsigned int Command;
unsigned char CS;
unsigned char Str[128];
unsigned long CurrentPos=0L;
unsigned long Adr=0L;
unsigned long AbsAdr=0L;
unsigned long Segment=0L;
unsigned char cTmp;
long count=0;


unsigned short Errors=0;


        printf("\r\n");

    while(1)
        {

        while(fgetc(HandleIN) != ':');

                printf("%ld",++count); putchar(13);


                CS=0;

        Len=getbin8();
        Adr=(unsigned long)getbin16();


        Command=getbin8();
        if(Command==1)
                        {

                        CS=CS+Len+(Adr>>8) + Adr+Command;
                        CS=~CS+1;

                        if(getbin8() != CS)
                                {
                                fprintf(HandleREP,"\n%.4X Неверная контрольная сумма!",Adr);
                                Errors++;
                                }
                        break;

                        }


        if(Command==2)
            {

                        AbsAdr=(unsigned long)getbin16();

                        CS=CS+Len+(Adr>>8) + Adr+ Command + (AbsAdr>>8) + AbsAdr;
                        CS=~CS+1;



                        if(getbin8() != CS)
                                {
                                fprintf(HandleREP,"\n%.4X Неверная контрольная сумма!",Adr);
                                Errors++;
                                }

                        AbsAdr=AbsAdr<<4+Adr;


            }

                if(Command==4)
            {
            AbsAdr=(unsigned long)getbin16();

                        CS=CS+Len+(Adr>>8) + Adr+ Command + (AbsAdr>>8) + AbsAdr;

                        AbsAdr=(AbsAdr<<16)+Adr;


                        CS=~CS+1;

                        if(getbin8() != CS)
                                {
                                fprintf(HandleREP,"\n%.4X Неверная контрольная сумма!",Adr);
                                Errors++;
                                }

            }

        if(Command==0)
            {
                        CS=CS+Len+(Adr>>8) + Adr+Command;


                        if( ((AbsAdr + Adr) - offset)  != CurrentPos)
                {
                                CurrentPos = ( AbsAdr+Adr ) - offset;
                fseek(HandleOUT,CurrentPos,SEEK_SET);
                }

            for(i=0;i<Len;i++)
                                {
                Str[i]=getbin8();
                                CS+=Str[i];
                                }
                        CS=~CS+1;

                        if(getbin8() != CS)
                                {
                                fprintf(HandleREP,"\n%.4X Неверная контрольная сумма!",Adr);
                                Errors++;
                                }

            CurrentPos+=(unsigned long)Len;
            fwrite(Str,Len,1,HandleOUT);
            }

        }


        fprintf(HandleREP,"\n-------------------------------------",Adr);
        fprintf(HandleREP,"\nОшибок - %d",Errors);

        printf("\r\nОшибок - %d",Errors);

        if(Errors) printf(", смотри .REP файл...",Errors);

}


unsigned char   convert_buf[ 65536 ];
unsigned short  convert_offset;

static int fput_filter( unsigned char c, unsigned long addr, unsigned long addr_b, unsigned long fragment_len )
{
    if( ( addr >= addr_b ) && ( addr < ( addr_b + fragment_len ) ) )
    {
        fseek( HandleOUT, addr - addr_b, SEEK_SET );
        fputc( c, HandleOUT );
    }

    if( addr >= addr_b + fragment_len ) 
        return 1;
    else
        return 0;    
}

static void Convert_fragment32(unsigned long addr_b, unsigned long fragment_len)
{
unsigned long i;
unsigned int  len;
unsigned int  command;
unsigned long addr  = 0L;
unsigned long addrl = 0L;
unsigned long addrh = 0L;

    convert_offset = 0;

    for( i = 0; i < fragment_len; i++ ) fputc( 0xFF, HandleOUT );

    while(1)
    {
        while( fgetc(HandleIN) != ':');

        len     = getbin8();
        addrl   = (unsigned long)getbin16();
        command = getbin8();

        switch ( command )
        {
        case 1: return;
        case 0: addr    = addrh + addrl;
  
                for( i = 0; i < len; i++)
                    if( fput_filter( getbin8(), addr++, addr_b, fragment_len ) ) return;
                break;

        case 2: addrh = ((unsigned long)getbin16()) << 4;   break;
        case 4: addrh = ((unsigned long)getbin16()) << 16;  break;
        }
    }
}

void Convert_fragment( unsigned short addr_b, unsigned short fragment_len )
{
int i;
unsigned int  len;
unsigned int  command;
unsigned long addr=0L;

    convert_offset = 0;

    for( i = 0; i < 65536; i++ ) convert_buf[ i ] = 0xFF;

    while(1)
    {

        while( fgetc(HandleIN) != ':');

        len     = getbin8();
        addr    = (unsigned long)getbin16();
        command = getbin8();

        if( command == 1 ) break;
        if( command == 0 )
        {

            for( i = 0; i < len; i++)
                convert_buf[ i + addr ] = getbin8();
        }

    }

    
    fwrite( &convert_buf[ addr_b ], fragment_len, 1, HandleOUT);
}


void Convert(unsigned int MinA)
{
int i;
unsigned int Len;
unsigned int Command;
unsigned int KS;
unsigned char Str[128];
unsigned char c;
unsigned long CurrentPos=0L;
unsigned long Adr=0L;
unsigned long AbsAdr=0L;
unsigned long Segment=0L;
unsigned long CurrentAdr=0L;

unsigned char str[256];
unsigned char flag=0;
unsigned long OFFSET;
unsigned long CounterByte=0L;


    printf("\nНачальный адрес: 0x%.4X\n",MinA);

    OFFSET=MinA;

    while(1)
        {
        while(fgetc(HandleIN) != ':');
        Len=getbin8();
        Adr=(unsigned long)getbin16();



        Command=getbin8();
        if(Command==1)
            break;

        /*
        if(Command==2)
            {
            putch('+');
            Segment=(unsigned long)getbin16();
            CurrentAdr=Segment<<4;
            CurrentPos=CurrentAdr-AbsAdr;
            fseek(HandleOUT,CurrentPos-OFFSET,SEEK_SET);
            }

        if(Command==3)
            {
            AbsAdr=(unsigned long)getbin16();
            AbsAdr=AbsAdr<<16;
            AbsAdr=AbsAdr+getbin16();
            AbsAdr=AbsAdr >> 12;
            }
        */

        if(Command==0)
            {

            if( (CurrentAdr - AbsAdr + Adr) != CurrentPos)
                {
                CurrentPos=CurrentAdr+Adr;
                fseek(HandleOUT,CurrentPos-OFFSET,SEEK_SET);
                }

            for(i=0;i<Len;i++)
                Str[i]=getbin8();
            CounterByte+=(unsigned long)Len;
            CurrentPos+=(unsigned long)Len;
            fwrite(Str,Len,1,HandleOUT);
            }
        }


}

void Convert32(void)
{
int i;
unsigned int Len;
unsigned int Command;
unsigned char CS;
unsigned char Str[128];
unsigned long CurrentPos=0L;
unsigned long Adr=0L;
unsigned long AbsAdr=0L;
unsigned long Segment=0L;
unsigned char cTmp;
long count=0;


unsigned short Errors=0;


        printf("\r\n");

    while(1)
        {

        while(fgetc(HandleIN) != ':');

                printf("%ld",++count); putchar(13);


                CS=0;

        Len=getbin8();
        Adr=(unsigned long)getbin16();


        Command=getbin8();
        if(Command==1)
                        {

                        CS=CS+Len+(Adr>>8) + Adr+Command;
                        CS=~CS+1;

                        if(getbin8() != CS)
                                {
                                fprintf(HandleREP,"\n%.4X Неверная контрольная сумма!\n",Adr);
                                Errors++;
                                }
                        break;

                        }


        if(Command==2)
            {

                        AbsAdr=(unsigned long)getbin16();

                        CS=CS+Len+(Adr>>8) + Adr+ Command + (AbsAdr>>8) + AbsAdr;
                        CS=~CS+1;



                        if(getbin8() != CS)
                                {
                                fprintf(HandleREP,"\n%.4X Неверная контрольная сумма!\n",Adr);
                                Errors++;
                                }

                        AbsAdr=AbsAdr<<4+Adr;


            }

                if(Command==4)
            {
            AbsAdr=(unsigned long)getbin16();

                        CS=CS+Len+(Adr>>8) + Adr+ Command + (AbsAdr>>8) + AbsAdr;

                        AbsAdr=(AbsAdr<<16)+Adr;


                        CS=~CS+1;

                        if(getbin8() != CS)
                                {
                                fprintf(HandleREP,"\n%.4X Неверная контрольная сумма!\n",Adr);
                                Errors++;
                                }

            }

        if(Command==0)
            {
                        CS=CS+Len+(Adr>>8) + Adr+Command;


                        if( (AbsAdr + Adr) != CurrentPos)
                {
                                CurrentPos=AbsAdr+Adr;
                fseek(HandleOUT,CurrentPos,SEEK_SET);
                }

            for(i=0;i<Len;i++)
                                {
                Str[i]=getbin8();
                                CS+=Str[i];
                                }
                        CS=~CS+1;

                        if(getbin8() != CS)
                                {
                                fprintf(HandleREP,"\n%.4X Неверная контрольная сумма!\n",Adr);
                                Errors++;
                                }

            CurrentPos+=(unsigned long)Len;
            fwrite(Str,Len,1,HandleOUT);
            }

        }


        fprintf(HandleREP,"\n-------------------------------------",Adr);
        fprintf(HandleREP,"\nОшибок - %d",Errors);

        printf("\r\nОшибок - %d",Errors);

        if(Errors) printf(", смотри .REP файл...\n",Errors);

}





void hb32(unsigned char * NameIn, unsigned char * NameOut)
{
int i;
unsigned char NameRep[100];





        printf("\nHex->Bin конвертер, 32-х разрядная версия. (b)");

        HandleIN=fopen((char*)NameIn,"rb");    if(HandleIN ==NULL) goto ErrorFileIN;
        HandleOUT=fopen((char*)NameOut,"wb");  if(HandleOUT==NULL) goto ErrorFileOUT;

        for(i=0;i<100;i++)
                {

                if( (NameOut[i]==0) || (NameOut[i]=='.') )
                        {
                        NameRep[i]='.';
                        NameRep[++i]='r';
                        NameRep[++i]='e';
                        NameRep[++i]='p';
                        NameRep[++i]=0;
                        break;

                        }
                 else
                        NameRep[i]=NameOut[i];
                }

        HandleREP=fopen((char*)NameRep,"wt");  if(HandleREP==NULL) goto ErrorFileREP;
        fprintf(HandleREP,"%s\n",NameRep);




    printf("\nФайл HEX       : %s",NameIn);
    printf("\nФайл BIN       : %s",NameOut);
        printf("\nФайл REP       : %s",NameRep);

        Convert32();
    fclose(HandleIN);
    fclose(HandleOUT);
        fclose(HandleREP);


        return;

ErrorFileIN:
        printf(" [hb32] Не открыть входной файл!\n");
    return;

ErrorFileOUT:
        printf(" [hb32] Не открыть выходной файл!\n");
    return;

ErrorFileREP:
        printf(" [hb32] Не открыть файл отчета!\n");
    return;

}



void hb32_offset(unsigned char * NameIn, unsigned char * NameOut)
{
int i;
unsigned char NameRep[100];





        printf("\nHex->Bin конвертер, 32-х разрядная версия. (b)");

        HandleIN=fopen((char*)NameIn,"rb");    if(HandleIN ==NULL) goto ErrorFileIN;
        HandleOUT=fopen((char*)NameOut,"wb");  if(HandleOUT==NULL) goto ErrorFileOUT;

        for(i=0;i<100;i++)
                {

                if( (NameOut[i]==0) || (NameOut[i]=='.') )
                        {
                        NameRep[i]='.';
                        NameRep[++i]='r';
                        NameRep[++i]='e';
                        NameRep[++i]='p';
                        NameRep[++i]=0;
                        break;

                        }
                 else
                        NameRep[i]=NameOut[i];
                }

        HandleREP=fopen((char*)NameRep,"wt");  if(HandleREP==NULL) goto ErrorFileREP;
        fprintf(HandleREP,"%s\n",NameRep);




    printf("\nФайл HEX       : %s",NameIn);
    printf("\nФайл BIN       : %s",NameOut);
        printf("\nФайл REP       : %s",NameRep);


    convert_32_offset( min_addr32() );

    fclose(HandleIN);
    fclose(HandleOUT);
        fclose(HandleREP);


        return;

ErrorFileIN:
        printf(" [hb32] Не открыть входной файл!\n");
    return;

ErrorFileOUT:
        printf(" [hb32] Не открыть выходной файл!\n");
    return;

ErrorFileREP:
        printf(" [hb32] Не открыть файл отчета!\n");
    return;

}





unsigned long  getbin16(void)
{
  unsigned long i;
  i = getbin8() << 8;
  return (i + getbin8());
}

unsigned long  getbin8(void)
{
  unsigned long i;
  i = getbin4() << 4;
  i += getbin4();
  return(i);
}

unsigned long  getbin4(void)
{
  unsigned long i;
  i = toupper(fgetc(HandleIN));
  return( isalpha(i) ? i - 'A' + 10 : i - '0');
}


