#include <stdio.h>

#include <sys/types.h>                     // 
#include <sys/stat.h>                      //   C library
#include <fcntl.h>                         //
#include <time.h>
#include <ex.h>
#include <mkdate.h>

MKDATE mk;


int MKDATE::CheckFile(void)
{
    handle=fopen("version.dat","rb");

    if(handle==NULL) 
        return 0;
     else
        {
        fclose(handle);
        return 1;
        }
}


void MKDATE::InitDATA(void)
{

    time((time_t *)&ver->ltime);

    ver->Version[0]=1;
    ver->Version[1]=0;
    ver->Version[2]=0;
    ver->Version[3]=1;

    ver->Build=1;

    ver->Type=V_STATUS_DEBUG;
   
    time((time_t *)&ver->ltime);

}


void MKDATE::WriteFile(void)
{
    handle=fopen("version.dat","wb"); if(handle==NULL) throw Ex_File();
    fwrite(ver,sizeof(VERSION),1,handle);
    fclose(handle);
}

void MKDATE::ReadFile(void)
{
    handle=fopen("version.dat","rb"); if(handle==NULL) throw Ex_File();
    fread(ver,sizeof(VERSION),1,handle);
    fclose(handle);
}




void MKDATE::Init(void)
{
/*
    Init:

[Idle] -Init-> [?file (version.dat)] ---  / ------ >[ END ]
                         I                                           ^  ^  
                         I                    +-------------N--------+  I   
                         I                    I                         I  
                         +--   -- [?user (Y/N)] --- Y/ --+
*/

    if(CheckFile())
    {
        printf("File version.dat exist, replace? [Y/N]"); fflush(stdout);
        char c=getchar();
        if( (c=='Y') || (c=='y') ) 
            {
            InitDATA();
            WriteFile();
            }
    }
     else
     {
         InitDATA();
         WriteFile();
     }

}

void MKDATE::operation( unsigned short version_status, unsigned short version_pos )
{

	if( version_status > V_STATUS_RELEASE ) return;
	if( version_pos >    V_POS_NULL ) 		return;


    if( CheckFile() )
    {

		GetVersion();

		if( version_status != V_STATUS_NULL )
			ver->Type = version_status; 	//     
		else
		{
			if( version_pos != V_POS_NULL )
				ver->Version[ version_pos ]++;
			else
		      	ver->Build++;							
		}
		
      	time((time_t *)&ver->ltime);

        WriteFile();
    }
    else
        Init();
}





void MKDATE::GetVersion(void)
{
    if( CheckFile() )
        ReadFile();
    else
        Init();

}

void MKDATE::ShowVersion(void)
{
    GetVersion();

    printf("Version = %d.%d.%d.%d\n",ver->Version[0],ver->Version[1],ver->Version[2],ver->Version[3]);
    printf("Build   = %d\n",ver->Build);
    printf("Type    = ");
    switch(ver->Type)
        {
        case V_STATUS_DEBUG:   printf("DEBUG version");   break;
        case V_STATUS_ALPHA:   printf("ALPHA version");   break;
        case V_STATUS_BETA:    printf("BETA version");    break;
        case V_STATUS_RELEASE: printf("RELEASE version"); break;
        }
    printf("\n");
      
    printf( "Date    = %s\n", ctime( (long *)&ver->ltime ) );
    
}
